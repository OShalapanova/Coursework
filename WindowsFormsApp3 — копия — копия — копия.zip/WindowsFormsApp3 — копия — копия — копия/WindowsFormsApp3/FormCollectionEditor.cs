﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormCollectionEditor : Form
    {
        public string CollectionName { get; private set; }
        public string Description { get; private set; }

        public FormCollectionEditor(string name = "", string description = "")
        {
            InitializeComponent();
            txtName.Text = name;
            txtDescription.Text = description;
            txtName.Select();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название коллекции", "Ошибка");
                return;
            }
            CollectionName = txtName.Text.Trim();
            Description = txtDescription.Text.Trim();
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
