﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormAddFilmToCollection : Form
    {
        private int collectionId;
        private string username;
        public FormAddFilmToCollection(int collectionId, string username)
        {
            InitializeComponent();
            this.collectionId = collectionId;
            this.username = username;
            LoadAvailableFilms();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (dgvAvailableFilms.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите фильм для добавления", "Информация");
                return;
            }

            try
            {
                int filmId = Convert.ToInt32(dgvAvailableFilms.SelectedRows[0].Cells["FILM_ID"].Value);
                string filmName = dgvAvailableFilms.SelectedRows[0].Cells["TITLE"].Value.ToString();

                // Добавляем в коллекцию
                string query = $"INSERT INTO FILM_COLLECTION (FILM, COLLECTION) VALUES ({filmId}, {collectionId})";
                DatabaseHelper.ExecuteNonQuery(query);

                MessageBox.Show($"Фильм '{filmName}' добавлен в коллекцию!", "Успех");
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления: {ex.Message}", "Ошибка");
            }
        }
        private void LoadAvailableFilms()
        {
            try
            {
                // Загружаем все фильмы, которых НЕТ в коллекции
                string query = $@"
                    SELECT 
                        f.FILM_ID,
                        f.TITLE,
                        f.RELESE_YEAR,
                        f.RATING
                    FROM FILMS f
                    WHERE NOT EXISTS (
                        SELECT 1 FROM FILM_COLLECTION fc 
                        WHERE fc.FILM = f.FILM_ID AND fc.COLLECTION = {collectionId}
                    )
                    ORDER BY f.TITLE";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgvAvailableFilms.DataSource = dt;

                // Настройка отображения
                if (dgvAvailableFilms.Columns.Contains("FILM_ID"))
                    dgvAvailableFilms.Columns["FILM_ID"].Visible = false;

                if (dgvAvailableFilms.Columns.Contains("TITLE"))
                {
                    dgvAvailableFilms.Columns["TITLE"].HeaderText = "Название";
                    dgvAvailableFilms.Columns["TITLE"].Width = 250;
                }

                if (dgvAvailableFilms.Columns.Contains("RELESE_YEAR"))
                {
                    dgvAvailableFilms.Columns["RELESE_YEAR"].HeaderText = "Год";
                    dgvAvailableFilms.Columns["RELESE_YEAR"].Width = 80;
                }

                if (dgvAvailableFilms.Columns.Contains("RATING"))
                {
                    dgvAvailableFilms.Columns["RATING"].HeaderText = "Рейтинг";
                    dgvAvailableFilms.Columns["RATING"].Width = 80;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки фильмов: {ex.Message}", "Ошибка");
            }
        }
        }
}
