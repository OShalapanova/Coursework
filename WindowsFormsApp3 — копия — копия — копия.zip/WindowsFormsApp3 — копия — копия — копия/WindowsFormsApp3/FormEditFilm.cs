﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormEditFilm : Form
    {
        private string username;
        private int? filmId;

        public FormEditFilm(string username, int? filmId = null)
        {
            InitializeComponent();
            this.username = username;
            this.filmId = filmId;

            LoadCountries();
            LoadAllGenres();

            if (filmId.HasValue)
            {
                LoadFilmData(filmId.Value);
                this.Text = "Редактировать фильм";
            }
            else
            {
                this.Text = "Добавить фильм";
            }
        }

        private void LoadCountries()
        {
            string query = "SELECT COUNTRY_CODE, COUNTRY_NAME FROM COUNTRIES ORDER BY COUNTRY_NAME";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            cmbCountry.DisplayMember = "COUNTRY_NAME";
            cmbCountry.ValueMember = "COUNTRY_CODE";
            cmbCountry.DataSource = dt;
        }

        private void LoadAllGenres()
        {
            try
            {
                string query = "SELECT GENRE_NAME FROM GENRES ORDER BY GENRE_NAME";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);

                checkedListBox1.Items.Clear();

                foreach (DataRow row in dt.Rows)
                {
                    checkedListBox1.Items.Add(row["GENRE_NAME"].ToString(), false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки жанров: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadFilmData(int filmId)
        {
            string query = $"SELECT * FROM FILMS WHERE FILM_ID = {filmId}";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            if (dt.Rows.Count > 0)
            {
                var row = dt.Rows[0];
                txtTitle.Text = row["TITLE"].ToString();
                nudYear.Value = Convert.ToInt32(row["RELESE_YEAR"]);
                txtType.Text = row["PRODUCT_TYPE"].ToString();
                txtDuration.Text = row["DURATION"]?.ToString() ?? "";
                txtRating.Text = row["RATING"]?.ToString() ?? "";
                txtDescription.Text = row["DESCRIPTION"]?.ToString() ?? "";

                if (row["COUNTRY_CODE"] != DBNull.Value)
                {
                    cmbCountry.SelectedValue = row["COUNTRY_CODE"].ToString();
                }

                if (row["POSTER"] != DBNull.Value)
                {
                    byte[] bytes = (byte[])row["POSTER"];
                    pbPoster.Image = DatabaseHelper.GetImageFromBytes(bytes);
                }

                // Загружаем жанры фильма из таблицы FILM_GENRE
                LoadFilmGenres(filmId);
            }
        }

        private void LoadFilmGenres(int filmId)
        {
            try
            {
                string query = $@"
                    SELECT g.GENRE_NAME 
                    FROM FILM_GENRE fg
                    JOIN GENRES g ON fg.GENRE_NAME = g.GENRE_NAME
                    WHERE fg.FILM_ID = {filmId}";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);

                // Очищаем все выборы
                for (int i = 0; i < checkedListBox1.Items.Count; i++)
                {
                    checkedListBox1.SetItemChecked(i, false);
                }

                // Отмечаем жанры фильма
                foreach (DataRow row in dt.Rows)
                {
                    string genreName = row["GENRE_NAME"].ToString();
                    int index = checkedListBox1.Items.IndexOf(genreName);
                    if (index >= 0)
                    {
                        checkedListBox1.SetItemChecked(index, true);
                    }
                }

                // Обновляем поле txtType (жанры через запятую)
                UpdateGenresDisplay();
            }
            catch (Exception ex)
            {
                // Можно просто пропустить ошибку
            }
        }

        private void UpdateGenresDisplay()
        {
            List<string> selectedGenres = GetSelectedGenres();
            if (selectedGenres.Count > 0)
            {
                txtType.Text = string.Join(", ", selectedGenres);
            }
            else
            {
                txtType.Text = "";
            }
        }

        private void btnLoadPoster_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        pbPoster.Image = Image.FromFile(dlg.FileName);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Не удалось загрузить изображение:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Введите название фильма", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(nudYear.Text, out int releaseYear) || releaseYear < 1888)
            {
                MessageBox.Show("Год выпуска должен быть числом ≥ 1888", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(txtDuration.Text, out int duration) || duration <= 0)
            {
                MessageBox.Show("Длительность должна быть положительным числом", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!decimal.TryParse(txtRating.Text, out decimal rating) || rating < 0 || rating > 10)
            {
                MessageBox.Show("Рейтинг должен быть числом от 0 до 10", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Получаем выбранные жанры
            List<string> selectedGenres = GetSelectedGenres();
            if (selectedGenres.Count == 0)
            {
                MessageBox.Show("Выберите хотя бы один жанр", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                checkedListBox1.Focus();
                return;
            }

            // Получаем выбранную страну
            string countryCode = "";
            if (cmbCountry.SelectedValue != null)
                countryCode = cmbCountry.SelectedValue.ToString();

            byte[] posterBytes = null;
            if (pbPoster.Image != null)
            {
                try
                {
                    using (Bitmap clone = new Bitmap(pbPoster.Image))
                    {
                        using (MemoryStream ms = new MemoryStream())
                        {
                            clone.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                            posterBytes = ms.ToArray();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка сохранения постера: {ex.Message}", "Ошибка");
                    return;
                }
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                FbCommand cmd;
                FbTransaction transaction = conn.BeginTransaction();

                try
                {
                    // Получаем ID фильма (новый или существующий)
                    int currentFilmId = 0;

                    if (filmId.HasValue)
                    {
                        // UPDATE существующего фильма
                        currentFilmId = filmId.Value;
                        cmd = new FbCommand(@"
        UPDATE FILMS SET
            TITLE = @title,
            RELESE_YEAR = @year,
            PRODUCT_TYPE = @type,
            COUNTRY_CODE = @country,
            DURATION = @duration,
            RATING = @rating,
            DESCRIPTION = @desc,
            POSTER = @poster,
            CREATED_ADMIN = @admin
        WHERE FILM_ID = @id", conn, transaction);

                        cmd.Parameters.AddWithValue("@id", currentFilmId);
                        cmd.Parameters.AddWithValue("@admin", username);
                        cmd.Parameters.AddWithValue("@title", txtTitle.Text.Trim());  // ✅ Добавлено!
                        cmd.Parameters.AddWithValue("@year", releaseYear);
                        cmd.Parameters.AddWithValue("@type", txtType.Text);
                        if (!string.IsNullOrEmpty(countryCode))
                            cmd.Parameters.AddWithValue("@country", countryCode);
                        else
                            cmd.Parameters.AddWithValue("@country", DBNull.Value);
                        cmd.Parameters.AddWithValue("@duration", duration);
                        cmd.Parameters.AddWithValue("@rating", rating);
                        if (!string.IsNullOrEmpty(txtDescription.Text))
                            cmd.Parameters.AddWithValue("@desc", txtDescription.Text.Trim());
                        else
                            cmd.Parameters.AddWithValue("@desc", DBNull.Value);
                        if (posterBytes != null)
                            cmd.Parameters.AddWithValue("@poster", posterBytes);
                        else
                            cmd.Parameters.AddWithValue("@poster", DBNull.Value);

                        cmd.ExecuteNonQuery();
                    }
                    else
                    {
                        // INSERT нового фильма
                        cmd = new FbCommand(@"
        INSERT INTO FILMS 
        (TITLE, RELESE_YEAR, PRODUCT_TYPE, COUNTRY_CODE, DURATION, RATING, DESCRIPTION, POSTER, CREATED_ADMIN)
        VALUES 
        (@title, @year, @type, @country, @duration, @rating, @desc, @poster, @admin)
        RETURNING FILM_ID", conn, transaction);

                        cmd.Parameters.AddWithValue("@admin", username);
                        cmd.Parameters.AddWithValue("@title", txtTitle.Text.Trim());  // ✅ Добавлено!
                        cmd.Parameters.AddWithValue("@year", releaseYear);
                        cmd.Parameters.AddWithValue("@type", txtType.Text);
                        if (!string.IsNullOrEmpty(countryCode))
                            cmd.Parameters.AddWithValue("@country", countryCode);
                        else
                            cmd.Parameters.AddWithValue("@country", DBNull.Value);
                        cmd.Parameters.AddWithValue("@duration", duration);
                        cmd.Parameters.AddWithValue("@rating", rating);
                        if (!string.IsNullOrEmpty(txtDescription.Text))
                            cmd.Parameters.AddWithValue("@desc", txtDescription.Text.Trim());
                        else
                            cmd.Parameters.AddWithValue("@desc", DBNull.Value);
                        if (posterBytes != null)
                            cmd.Parameters.AddWithValue("@poster", posterBytes);
                        else
                            cmd.Parameters.AddWithValue("@poster", DBNull.Value);

                        // ✅ ЭТА СТРОКА БЫЛА ДОБАВЛЕНА:
                        var result = cmd.ExecuteScalar();
                        currentFilmId = Convert.ToInt32(result);
                    }

                    // Сохраняем жанры в таблице FILM_GENRE
                    SaveFilmGenres(currentFilmId, selectedGenres, conn, transaction);

                    transaction.Commit();
                    MessageBox.Show("Фильм успешно сохранён!", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show($"Ошибка сохранения:\n{ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private List<string> GetSelectedGenres()
        {
            List<string> selected = new List<string>();
            foreach (string item in checkedListBox1.CheckedItems)
            {
                selected.Add(item);
            }
            return selected;
        }

        // ✅ ИСПРАВЛЕННЫЙ МЕТОД SaveFilmGenres (только он изменён)
        private void SaveFilmGenres(int filmId, List<string> genres, FbConnection conn, FbTransaction transaction)
        {
            try
            {
                // Удаляем все старые жанры этого фильма
                string deleteQuery = "DELETE FROM FILM_GENRE WHERE FILM_ID = @filmId";
                using (FbCommand deleteCmd = new FbCommand(deleteQuery, conn, transaction))
                {
                    deleteCmd.Parameters.AddWithValue("@filmId", filmId);
                    deleteCmd.ExecuteNonQuery();
                }

                // Добавляем новые жанры
                foreach (string genre in genres)
                {
                    string insertQuery = "INSERT INTO FILM_GENRE (FILM_ID, GENRE_NAME) VALUES (@filmId, @genreName)";
                    using (FbCommand insertCmd = new FbCommand(insertQuery, conn, transaction))
                    {
                        insertCmd.Parameters.AddWithValue("@filmId", filmId);
                        insertCmd.Parameters.AddWithValue("@genreName", genre);
                        insertCmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка сохранения жанров: {ex.Message}");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        // Обработчик изменения выбора в CheckedListBox
        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Обновляем отображение жанров через запятую
            this.BeginInvoke((MethodInvoker)delegate {
                UpdateGenresDisplay();
            });
        }

        // Методы для дизайнера (оставляем для совместимости)
        private void label1_Click(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
    }
}