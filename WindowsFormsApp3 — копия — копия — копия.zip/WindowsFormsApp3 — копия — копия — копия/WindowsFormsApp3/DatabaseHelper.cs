﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using FirebirdSql.Data.FirebirdClient;

namespace WindowsFormsApp3
{
    public static class DatabaseHelper
    {
        private static string connectionString =
            "Database=localhost/3050:D:\\base.fdb;" +
            "User=sysdba;" +
            "Password=masterkey;" +
            "Charset=UTF8;";

        public static FbConnection GetConnection()
        {
            return new FbConnection(connectionString);
        }

        public static DataTable ExecuteQuery(string query)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new FbCommand(query, connection))
                {
                    DataTable dt = new DataTable();
                    dt.Load(command.ExecuteReader());
                    return dt;
                }
            }
        }

        public static int ExecuteNonQuery(string query)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new FbCommand(query, connection))
                {
                    return command.ExecuteNonQuery();
                }
            }
        }

        public static object ExecuteScalar(string query)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new FbCommand(query, connection))
                {
                    return command.ExecuteScalar();
                }
            }
        }

        public static byte[] GetImageBytes(Image image)
        {
            if (image == null) return null;
            using (MemoryStream ms = new MemoryStream())
            {
                image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                return ms.ToArray();
            }
        }

        public static Image GetImageFromBytes(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0) return null;
            using (MemoryStream ms = new MemoryStream(bytes))
            {
                return Image.FromStream(ms);
            }
        }
    }
}