﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;

namespace WindowsFormsApp3
{
    public partial class FormRegister : Form
    {
        public FormRegister()
        {
            InitializeComponent();
            txtPassword.PasswordChar = '*';
            txtConfirm.PasswordChar = '*';
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text;
            string confirm = txtConfirm.Text;

            // Проверка заполнения
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) ||
                string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirm))
            {
                MessageBox.Show("Заполните все поля", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Проверка паролей
            if (password != confirm)
            {
                MessageBox.Show("Пароли не совпадают", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Проверка email
            if (!email.Contains("@") || !email.Contains("."))
            {
                MessageBox.Show("Введите корректный email", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Проверка существующего пользователя
                string checkQuery = $"SELECT COUNT(*) FROM USERS WHERE USER_NAME = '{username}' OR EMAIL = '{email}'";
                object checkResult = DatabaseHelper.ExecuteScalar(checkQuery);

                int exists = 0;
                if (checkResult != null && checkResult != DBNull.Value)
                {
                    exists = Convert.ToInt32(checkResult);
                }

                if (exists > 0)
                {
                    MessageBox.Show("Пользователь с таким именем или email уже существует",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Регистрация с паролем
                string insertQuery = $"INSERT INTO USERS (USER_NAME, EMAIL, PASSWORD) VALUES ('{username}', '{email}', '{password}')";
                int result = DatabaseHelper.ExecuteNonQuery(insertQuery);

                if (result > 0)
                {
                    MessageBox.Show($"Регистрация успешна!\n\n" +
                                  "Данные для входа:\n" +
                                  $"Логин: {username}\n" +
                                  $"Пароль: {password}",
                        "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при регистрации: {ex.Message}\n\n" +
                              "Убедитесь, что столбец PASSWORD добавлен в таблицу USERS:\n" +
                              "ALTER TABLE USERS ADD PASSWORD VARCHAR(255)",
                              "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
