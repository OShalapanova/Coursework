﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using WindowsFormsApp3;

namespace WindowsFormsApp3
{
    public partial class FormUser : Form
    {
        private string username;

        public FormUser(string username)
        {
            this.username = username;
            InitializeComponent();
            SetupForm();
            LoadData();

            // Привязываем событие клика по коллекции
            dvgCollections.CellClick += dvgCollections_CellClick;
        }

        private void SetupForm()
        {
            this.Text = $"Кинотека - Пользователь: {username}";

            dvgFilms.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dvgFilms.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dvgFilms.ReadOnly = true;

            dvgCollections.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dvgCollections.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dvgCollections.ReadOnly = true;

            cmbGenreFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCountryFilter.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void LoadData()
        {
            LoadFilms();
            LoadCollections();
            LoadFilters();
        }

        private void LoadFilms()
        {
            try
            {
                string query = @"
                    SELECT 
                        f.FILM_ID as ""ID"",
                        f.TITLE as ""Название"",
                        f.RATING as ""Рейтинг"",
                        COALESCE(f.DESCRIPTION, '') as ""Описание""
                    FROM FILMS f
                    ORDER BY f.RATING DESC, f.TITLE";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dvgFilms.DataSource = dt;
                dvgFilms.Columns["ID"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки фильмов: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadCollections()
        {
            try
            {
                string query = $@"
                    SELECT 
                        COLLECTIONS_ID as ""ID"", 
                        TITLE as ""Название"",
                        DESCRIPTION as ""Описание""
                    FROM COLLECTIONS 
                    WHERE USER_NAME = '{username}'";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dvgCollections.DataSource = dt;
                dvgCollections.Columns["ID"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки коллекций: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadFilters()
        {
            try
            {
                // Жанры
                cmbGenreFilter.Items.Clear();
                cmbGenreFilter.Items.Add("Все жанры");
                DataTable genres = DatabaseHelper.ExecuteQuery("SELECT GENRE_NAME FROM GENRES ORDER BY GENRE_NAME");
                foreach (DataRow row in genres.Rows)
                    cmbGenreFilter.Items.Add(row["GENRE_NAME"].ToString());
                cmbGenreFilter.SelectedIndex = 0;

                // Страны
                cmbCountryFilter.Items.Clear();
                cmbCountryFilter.Items.Add("Все страны");
                DataTable countries = DatabaseHelper.ExecuteQuery("SELECT COUNTRY_NAME FROM COUNTRIES ORDER BY COUNTRY_NAME");
                foreach (DataRow row in countries.Rows)
                    cmbCountryFilter.Items.Add(row["COUNTRY_NAME"].ToString());
                cmbCountryFilter.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки фильтров: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bntBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormMain().Show();
        }

        private void bntNewCollection_Click(object sender, EventArgs e)
        {
            var editor = new FormCollectionEditor();
            if (editor.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string query = $@"
                        INSERT INTO COLLECTIONS (TITLE, USER_NAME, DESCRIPTION) 
                        VALUES ('{editor.CollectionName}', '{username}', '{editor.Description}')";
                    DatabaseHelper.ExecuteNonQuery(query);
                    MessageBox.Show("Коллекция создана!", "Успех");
                    LoadCollections();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
                }
            }
        }

        private void bntEditCollection_Click(object sender, EventArgs e)
        {
            if (dvgCollections.SelectedRows.Count == 0) return;

            int id = Convert.ToInt32(dvgCollections.SelectedRows[0].Cells["ID"].Value);
            string name = dvgCollections.SelectedRows[0].Cells["Название"].Value.ToString();
            string desc = dvgCollections.SelectedRows[0].Cells["Описание"]?.Value?.ToString() ?? "";

            var editor = new FormCollectionEditor(name, desc);
            if (editor.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string query = $@"
                        UPDATE COLLECTIONS 
                        SET TITLE = '{editor.CollectionName}', DESCRIPTION = '{editor.Description}'
                        WHERE COLLECTIONS_ID = {id}";
                    DatabaseHelper.ExecuteNonQuery(query);
                    MessageBox.Show("Коллекция обновлена!", "Успех");
                    LoadCollections();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
                }
            }
        }

        private void bntDeleteCollection_Click(object sender, EventArgs e)
        {
            if (dvgCollections.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите коллекцию для удаления", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int collectionId = Convert.ToInt32(dvgCollections.SelectedRows[0].Cells["ID"].Value);
            string collectionName = dvgCollections.SelectedRows[0].Cells["Название"].Value.ToString();

            if (MessageBox.Show($"Удалить коллекцию '{collectionName}'?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string deleteQuery = $"DELETE FROM COLLECTIONS WHERE COLLECTIONS_ID = {collectionId}";
                    if (DatabaseHelper.ExecuteNonQuery(deleteQuery) > 0)
                    {
                        MessageBox.Show("Коллекция удалена", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadCollections();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e) => ApplyFilters();
        private void cmbGenreFilter_SelectedIndexChanged(object sender, EventArgs e) => ApplyFilters();
        private void cmbCountryFilter_SelectedIndexChanged(object sender, EventArgs e) => ApplyFilters();

        private void ApplyFilters()
        {
            try
            {
                string search = txtSearch.Text.Trim();
                string genre = cmbGenreFilter.SelectedIndex > 0 ? cmbGenreFilter.Text : "";
                string country = cmbCountryFilter.SelectedIndex > 0 ? cmbCountryFilter.Text : "";

                string query = @"
                    SELECT 
                        f.FILM_ID as ""ID"",
                        f.TITLE as ""Название"",
                        f.RATING as ""Рейтинг"",
                        f.DESCRIPTION as ""Описание""
                    FROM FILMS f
                    WHERE 1=1";

                if (!string.IsNullOrEmpty(search))
                    query += $" AND (UPPER(f.TITLE) LIKE UPPER('%{search}%') OR UPPER(f.DESCRIPTION) LIKE UPPER('%{search}%'))";
                if (!string.IsNullOrEmpty(genre))
                    query += $" AND EXISTS (SELECT 1 FROM FILM_GENRE fg WHERE fg.FILM_ID = f.FILM_ID AND fg.GENRE_NAME = '{genre}')";
                if (!string.IsNullOrEmpty(country))
                    query += $" AND EXISTS (SELECT 1 FROM COUNTRIES c WHERE c.COUNTRY_NAME = '{country}' AND c.COUNTRY_CODE = f.COUNTRY_CODE)";

                query += " ORDER BY f.RATING DESC, f.TITLE";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dvgFilms.DataSource = dt;
                dvgFilms.Columns["ID"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка фильтрации: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dvgFilms_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dvgFilms.Rows[e.RowIndex].Cells["ID"].Value != null)
            {
                try
                {
                    int filmId = Convert.ToInt32(dvgFilms.Rows[e.RowIndex].Cells["ID"].Value);
                    new FormFilmDetails(filmId, username).ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка открытия деталей фильма: {ex.Message}", "Ошибка");
                }
            }
        }

        // ✅ ОСНОВНОЕ ИЗМЕНЕНИЕ: открываем коллекцию при клике на любую ячейку строки
        private void dvgCollections_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            try
            {
                if (dvgCollections.Rows[e.RowIndex].Cells["ID"].Value != null)
                {
                    int collectionId = Convert.ToInt32(dvgCollections.Rows[e.RowIndex].Cells["ID"].Value);
                    ViewCollection(collectionId);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка открытия коллекции: {ex.Message}", "Ошибка");
            }
        }

        private void ViewCollection(int collectionId)
        {
            try
            {
                // Получаем название коллекции
                string collectionQuery = $"SELECT TITLE FROM COLLECTIONS WHERE COLLECTIONS_ID = {collectionId}";
                DataTable collectionData = DatabaseHelper.ExecuteQuery(collectionQuery);

                if (collectionData.Rows.Count == 0)
                {
                    MessageBox.Show("Коллекция не найдена", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string collectionName = collectionData.Rows[0]["TITLE"].ToString();

                // Создаем форму с фиксированным размером
                Form viewForm = new Form();
                viewForm.Text = $"Коллекция: {collectionName}";
                viewForm.Size = new Size(600, 400); // Уменьшили размер
                viewForm.StartPosition = FormStartPosition.CenterParent;

                // DataGridView для фильмов — занимает всё пространство, кроме места под кнопки
                DataGridView dgv = new DataGridView();
                dgv.Name = "dgvCollectionFilms";
                dgv.Dock = DockStyle.Top; // Прикрепляем к верху
                dgv.Height = 300; // Фиксируем высоту таблицы
                dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgv.ReadOnly = true;
                dgv.AllowUserToAddRows = false;
                dgv.AllowUserToDeleteRows = false;

                // Загружаем фильмы коллекции — используем RELESE_YEAR (как в базе)
                string filmsQuery = $@"
    SELECT 
        f.FILM_ID as ""ID"",
        f.TITLE as ""Название"",
        f.RELESE_YEAR as ""Год выпуска"",
        f.PRODUCT_TYPE as ""Тип"",
        f.DURATION as ""Длительность"",
        f.RATING as ""Рейтинг""
    FROM FILMS f
    INNER JOIN FILM_COLLECTION fc ON f.FILM_ID = fc.FILM
    WHERE fc.COLLECTION = {collectionId}
    ORDER BY f.TITLE";

                DataTable filmsData = DatabaseHelper.ExecuteQuery(filmsQuery);
                dgv.DataSource = filmsData;

                // Скрываем колонку ID
                if (dgv.Columns.Contains("ID"))
                {
                    dgv.Columns["ID"].Visible = false;
                }

                // Настройка заголовков столбцов
                if (dgv.Columns.Contains("Title")) dgv.Columns["Title"].HeaderText = "Название";
                if (dgv.Columns.Contains("Year")) dgv.Columns["Year"].HeaderText = "Год";
                if (dgv.Columns.Contains("Type")) dgv.Columns["Type"].HeaderText = "Тип";
                if (dgv.Columns.Contains("Dur")) dgv.Columns["Dur"].HeaderText = "Длительность";
                if (dgv.Columns.Contains("Rating")) dgv.Columns["Rating"].HeaderText = "Рейтинг";

                // Панель для кнопок внизу
                Panel buttonPanel = new Panel();
                buttonPanel.Dock = DockStyle.Bottom;
                buttonPanel.Height = 50;
                buttonPanel.Padding = new Padding(10);

                // Кнопка "Назад"
                Button btnBack = new Button();
                btnBack.Text = "Назад";
                btnBack.Size = new Size(100, 30);
                btnBack.Location = new Point(10, 10);
                btnBack.Click += (s, ev) => viewForm.Close();

                // Кнопка "Удалить фильм"
                Button btnRemove = new Button();
                btnRemove.Text = "Удалить фильм";
                btnRemove.Size = new Size(120, 30);
                btnRemove.Location = new Point(120, 10);
                btnRemove.Click += (s, ev) =>
                {
                    if (dgv.SelectedRows.Count > 0)
                    {
                        int filmId = Convert.ToInt32(dgv.SelectedRows[0].Cells["ID"].Value);
                        string filmName = dgv.SelectedRows[0].Cells["Title"].Value.ToString();

                        DialogResult result = MessageBox.Show(
                            $"Удалить фильм '{filmName}' из коллекции '{collectionName}'?",
                            "Подтверждение удаления",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question);

                        if (result == DialogResult.Yes)
                        {
                            try
                            {
                                string deleteQuery = $"DELETE FROM FILM_COLLECTION WHERE FILM = {filmId} AND COLLECTION = {collectionId}";
                                DatabaseHelper.ExecuteNonQuery(deleteQuery);

                                // Обновляем список
                                DataTable updatedData = DatabaseHelper.ExecuteQuery(filmsQuery);
                                dgv.DataSource = updatedData;

                                MessageBox.Show($"Фильм '{filmName}' удален из коллекции", "Успех",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Выберите фильм для удаления", "Информация",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                };

                // Добавляем кнопки на панель
                buttonPanel.Controls.Add(btnBack);
                buttonPanel.Controls.Add(btnRemove);

                // Добавляем элементы на форму
                viewForm.Controls.Add(dgv);
                viewForm.Controls.Add(buttonPanel);

                // Обработчик двойного клика по фильму
                dgv.CellDoubleClick += (s, ev) =>
                {
                    if (ev.RowIndex >= 0 && dgv.Rows[ev.RowIndex].Cells["ID"].Value != null)
                    {
                        int filmId = Convert.ToInt32(dgv.Rows[ev.RowIndex].Cells["ID"].Value);
                        viewForm.Hide();
                        FormFilmDetails detailsForm = new FormFilmDetails(filmId, username);
                        detailsForm.ShowDialog();
                        viewForm.Show();
                    }
                };

                viewForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки коллекции: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void AddFilmToCollection(int collectionId, string refreshQuery, DataGridView dgv)
        {
            try
            {
                // ✅ Исправлено: 'ID' → "ID"
                string query = $@"
                    SELECT 
                        f.FILM_ID as ""ID"",
                        f.TITLE as ""Название"",
                        f.RELESE_YEAR as ""Год"",
                        f.RATING as ""Рейтинг""
                    FROM FILMS f
                    WHERE NOT EXISTS (
                        SELECT 1 FROM FILM_COLLECTION fc 
                        WHERE fc.FILM = f.FILM_ID AND fc.COLLECTION = {collectionId}
                    )
                    ORDER BY f.TITLE";

                var selectForm = new Form
                {
                    Text = "Добавить фильм в коллекцию",
                    Size = new Size(600, 400),
                    StartPosition = FormStartPosition.CenterParent
                };

                DataGridView dgvAll = new DataGridView
                {
                    Dock = DockStyle.Top,
                    Height = 300,
                    AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                    SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                    ReadOnly = true
                };

                DataTable films = DatabaseHelper.ExecuteQuery(query);
                dgvAll.DataSource = films;
                if (dgvAll.Columns.Contains("ID")) dgvAll.Columns["ID"].Visible = false;

                Button btnAdd = new Button { Text = "Добавить выбранный", Size = new Size(150, 30), Location = new Point(10, 310) };
                btnAdd.Click += (s, e) =>
                {
                    if (dgvAll.SelectedRows.Count == 0)
                    {
                        MessageBox.Show("Выберите фильм", "Информация");
                        return;
                    }

                    int filmId = Convert.ToInt32(dgvAll.SelectedRows[0].Cells["ID"].Value);
                    string name = dgvAll.SelectedRows[0].Cells["Название"].Value.ToString();

                    try
                    {
                        DatabaseHelper.ExecuteNonQuery($"INSERT INTO FILM_COLLECTION (FILM, COLLECTION) VALUES ({filmId}, {collectionId})");
                        MessageBox.Show($"Фильм '{name}' добавлен в коллекцию", "Успех");
                        dgv.DataSource = DatabaseHelper.ExecuteQuery(refreshQuery); // Обновляем основной список
                        dgvAll.DataSource = DatabaseHelper.ExecuteQuery(query);       // Обновляем доступные фильмы
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
                    }
                };

                Button btnCancel = new Button { Text = "Отмена", Size = new Size(100, 30), Location = new Point(170, 310) };
                btnCancel.Click += (s, e) => selectForm.Close();

                selectForm.Controls.Add(dgvAll);
                selectForm.Controls.Add(btnAdd);
                selectForm.Controls.Add(btnCancel);
                selectForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
            }
        }

        // Кнопка "Добавить фильм в коллекцию" из основного интерфейса
        private void button1_Click(object sender, EventArgs e)
        {
            if (dvgCollections.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите коллекцию", "Информация");
                return;
            }

            int collectionId = Convert.ToInt32(dvgCollections.SelectedRows[0].Cells["ID"].Value);
            var form = new FormAddFilmToCollection(collectionId, username);
            if (form.ShowDialog() == DialogResult.OK)
            {
                LoadCollections(); // можно обновить список коллекций
            }
        }
        private void lblCountry_Click(object sender, EventArgs e)
        {
            // Заглушка для избежания ошибки CS1061
        }

        private void searchPanel_Paint(object sender, PaintEventArgs e)
        {
            // Заглушка для избежания ошибки CS1061
        }

        private void dvgCollections_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Заглушка — основная логика теперь в dvgCollections_CellClick
        }
    }
}