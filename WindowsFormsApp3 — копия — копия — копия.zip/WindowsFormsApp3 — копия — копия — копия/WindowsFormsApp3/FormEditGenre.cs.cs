﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormEditGenre : Form
    {
        private string adminUsername;
        public FormEditGenre(string adminUsername)
        {
            InitializeComponent();
            this.adminUsername = adminUsername;
            Text = "Добавить жанр";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Укажите название жанра", "Ошибка");
                return;
            }
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new FbCommand(@"
                        INSERT INTO GENRES (GENRE_NAME, DESCRIPTION, CREATED_ADMIN)
                        VALUES (@name, @desc, @admin)", conn);
                    cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                    cmd.Parameters.AddWithValue("@desc", txtDescription.Text);
                    cmd.Parameters.AddWithValue("@admin", adminUsername);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Жанр добавлен!", "Успех");
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
    }

