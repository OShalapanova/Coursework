﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;

namespace WindowsFormsApp3
{
    public partial class FormLogin : Form
    {
        private string userType;
        public string Username { get; private set; }
        public FormLogin(string type)
        {
            InitializeComponent();
            userType = type;
            this.Text = userType == "admin" ? "Вход администратора" : "Вход пользователя";
            txtPassword.PasswordChar = '*';
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Заполните все поля", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                bool loginSuccess = false;

                if (userType == "admin")
                {
                    // Для администратора - проверяем таблицу ADMINS
                    string query = $"SELECT COUNT(*) FROM ADMINS WHERE LOGIN = '{username}' AND PASWORD = '{password}'";
                    object result = DatabaseHelper.ExecuteScalar(query);
                    loginSuccess = (result != null && Convert.ToInt32(result) > 0);
                }
                else
                {
                    // Для пользователя - проверяем таблицу USERS с новым столбцом PASSWORD
                    string query = $"SELECT COUNT(*) FROM USERS WHERE USER_NAME = '{username}' AND PASSWORD = '{password}'";
                    object result = DatabaseHelper.ExecuteScalar(query);
                    loginSuccess = (result != null && Convert.ToInt32(result) > 0);
                }

                if (loginSuccess)
                {
                    Username = username;
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка входа: {ex.Message}\n\n" +
                              "Убедитесь, что:\n" +
                              "1. Добавлен столбец PASSWORD в таблицу USERS\n" +
                              "2. Пользователи имеют пароли",
                              "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                btnLogin_Click(sender, e);
            }
        }
        private void bntCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }

 }
