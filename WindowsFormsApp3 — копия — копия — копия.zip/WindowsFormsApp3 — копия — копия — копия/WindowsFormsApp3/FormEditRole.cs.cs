﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormEditRole : Form
    {
        private string adminUsername;
        public FormEditRole(string adminUsername)
        {
            InitializeComponent();
            this.adminUsername = adminUsername;
        }

        private void lblDescription_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Укажите название роли", "Ошибка");
                return;
            }
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new FbCommand(@"
                        INSERT INTO ROLES (ROLE_NAME, DESCRIPTION, CREATED_ADMIN)
                        VALUES (@name, @desc, @admin)", conn);
                    cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                    cmd.Parameters.AddWithValue("@desc", txtDescription.Text);
                    cmd.Parameters.AddWithValue("@admin", adminUsername);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Роль добавлена!", "Успех");
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
