﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormEditAdmin : Form
    {
        private string currentAdmin;
        private bool isEditMode;

        public FormEditAdmin(string currentAdmin, string login = null, string password = "", string email = "")
        {
            InitializeComponent();
            this.currentAdmin = currentAdmin;

            isEditMode = !string.IsNullOrEmpty(login);

            if (isEditMode)
            {
                // Режим редактирования
                txtLogin.Text = login;
                txtPassword.Text = password;
                txtEmail.Text = email;
                txtLogin.Enabled = false; // Логин нельзя менять при редактировании
                Text = "Редактировать администратора";
            }
            else
            {
                // Режим добавления
                Text = "Добавить администратора";
                txtLogin.Enabled = true;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Проверка всех полей
            if (string.IsNullOrWhiteSpace(txtLogin.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Заполните все поля (логин, пароль и email)", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();

                    if (isEditMode)
                    {
                        // Обновление существующего администратора
                        var cmd = new FbCommand(@"
                            UPDATE ADMINS 
                            SET PASWORD = @pass, 
                                EMAIL = @email,
                                CREATED_ADMIN = @createAdmin
                            WHERE LOGIN = @login", conn);
                        cmd.Parameters.AddWithValue("@login", txtLogin.Text);
                        cmd.Parameters.AddWithValue("@pass", txtPassword.Text);
                        cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                        cmd.Parameters.AddWithValue("@createAdmin", currentAdmin); // Кто внес изменения

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Администратор обновлён!", "Успех",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            DialogResult = DialogResult.OK;
                            Close();
                        }
                        else
                        {
                            MessageBox.Show("Администратор не найден", "Ошибка",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        // Добавление нового администратора
                        // Сначала проверяем, не существует ли уже администратор с таким логином
                        var checkCmd = new FbCommand(
                            "SELECT COUNT(*) FROM ADMINS WHERE LOGIN = @login", conn);
                        checkCmd.Parameters.AddWithValue("@login", txtLogin.Text);
                        int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (count > 0)
                        {
                            MessageBox.Show("Администратор с таким логином уже существует", "Ошибка",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        // Добавляем нового администратора
                        var insertCmd = new FbCommand(@"
                            INSERT INTO ADMINS (LOGIN, PASWORD, EMAIL, CREATED_ADMIN)
                            VALUES (@login, @pass, @email, @createAdmin)", conn);
                        insertCmd.Parameters.AddWithValue("@login", txtLogin.Text);
                        insertCmd.Parameters.AddWithValue("@pass", txtPassword.Text);
                        insertCmd.Parameters.AddWithValue("@email", txtEmail.Text);
                        insertCmd.Parameters.AddWithValue("@createAdmin", currentAdmin); // Кто создал

                        int rowsInserted = insertCmd.ExecuteNonQuery();

                        if (rowsInserted > 0)
                        {
                            MessageBox.Show("Администратор добавлен!", "Успех",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            DialogResult = DialogResult.OK;
                            Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}