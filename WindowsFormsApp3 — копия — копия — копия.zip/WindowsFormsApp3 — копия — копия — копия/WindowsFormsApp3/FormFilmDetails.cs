﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormFilmDetails : Form
    {
        private int filmId;
        private string username;

        public FormFilmDetails(int filmId, string username)
        {
            InitializeComponent();
            this.filmId = filmId;
            this.username = username;
            LoadFilmDetails();
        }

        private void LoadFilmDetails()
        {
            try
            {
                // 1. Загрузка основной информации о фильме
                string query = $@"
                    SELECT 
                        f.TITLE,
                        f.RELESE_YEAR,
                        f.PRODUCT_TYPE,
                        f.DURATION,
                        f.RATING,
                        f.DESCRIPTION,
                        c.COUNTRY_NAME,
                        f.POSTER
                    FROM FILMS f
                    LEFT JOIN COUNTRIES c ON f.COUNTRY_CODE = c.COUNTRY_CODE
                    WHERE f.FILM_ID = {filmId}";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);

                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];

                    // Заполнение полей с проверкой на NULL
                    lblTitle.Text = row["TITLE"] != DBNull.Value ? row["TITLE"].ToString() : "Нет названия";
                    lblYear.Text = row["RELESE_YEAR"] != DBNull.Value ? $"Год: {row["RELESE_YEAR"]}" : "Год: не указан";
                    lblType.Text = row["PRODUCT_TYPE"] != DBNull.Value ? $"Тип: {row["PRODUCT_TYPE"]}" : "Тип: не указан";
                    lblDuration.Text = row["DURATION"] != DBNull.Value ? $"Длительность: {row["DURATION"]} мин" : "Длительность: не указана";
                    lblRating.Text = row["RATING"] != DBNull.Value ? $"Рейтинг: {row["RATING"]:0.0}" : "Рейтинг: не указан";
                    lblCountry.Text = row["COUNTRY_NAME"] != DBNull.Value ? $"Страна: {row["COUNTRY_NAME"]}" : "Страна: не указана";
                    txtDescription.Text = row["DESCRIPTION"] != DBNull.Value ? row["DESCRIPTION"].ToString() : "Описание отсутствует";

                    // Загрузка постера
                    if (row["POSTER"] != DBNull.Value && row["POSTER"] != null)
                    {
                        try
                        {
                            byte[] imageBytes = (byte[])row["POSTER"];
                            pbPoster.Image = DatabaseHelper.GetImageFromBytes(imageBytes);
                        }
                        catch (Exception ex)
                        {
                            // Проблема с загрузкой изображения
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Фильм не найден!", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                    return;
                }

                // 2. Загрузка съемочной группы
                LoadFilmCrew();

                // 3. Загрузка жанров
                LoadFilmGenres();

                // 4. Загрузка коллекций, в которых есть этот фильм
                LoadFilmCollections();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadFilmCrew()
        {
            try
            {
                string query = $@"
                    SELECT 
                        p.FIRST_NAME || ' ' || p.LAST_NAME AS PERSON_NAME,
                        r.ROLE_NAME AS ROLE,
                        fc.ROLE_FILM AS ROLE_DESC,
                        p.PEOPLE_ID
                    FROM FILM_CREW fc
                    JOIN PEOPLE p ON fc.PEOPLE_ID = p.PEOPLE_ID
                    JOIN ROLES r ON fc.TITLE_ROLE = r.ROLE_NAME
                    WHERE fc.FILM_ID = {filmId}
                    ORDER BY r.ROLE_NAME, p.LAST_NAME";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgvCrew.DataSource = dt;

                // Настраиваем отображение
                if (dgvCrew.Columns.Contains("PEOPLE_ID"))
                {
                    dgvCrew.Columns["PEOPLE_ID"].Visible = false;
                }

                if (dgvCrew.Columns.Contains("PERSON_NAME"))
                {
                    dgvCrew.Columns["PERSON_NAME"].HeaderText = "Имя";
                    dgvCrew.Columns["PERSON_NAME"].Width = 200;
                }

                if (dgvCrew.Columns.Contains("ROLE"))
                {
                    dgvCrew.Columns["ROLE"].HeaderText = "Роль";
                    dgvCrew.Columns["ROLE"].Width = 150;
                }

                if (dgvCrew.Columns.Contains("ROLE_DESC"))
                {
                    dgvCrew.Columns["ROLE_DESC"].HeaderText = "Описание роли";
                    dgvCrew.Columns["ROLE_DESC"].Width = 250;
                }

                // Визуальные настройки
                dgvCrew.Cursor = Cursors.Hand;
                dgvCrew.DefaultCellStyle.SelectionBackColor = Color.LightBlue;
                dgvCrew.ReadOnly = true;
                dgvCrew.AllowUserToAddRows = false;
                dgvCrew.AllowUserToDeleteRows = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки съемочной группы: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadFilmGenres()
        {
            try
            {
                string query = $@"
                    SELECT g.GENRE_NAME
                    FROM FILM_GENRE fg
                    JOIN GENRES g ON fg.GENRE_NAME = g.GENRE_NAME
                    WHERE fg.FILM_ID = {filmId}
                    ORDER BY g.GENRE_NAME";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);

                string genres = "Жанры: ";
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        genres += row["GENRE_NAME"].ToString() + ", ";
                    }
                    genres = genres.Substring(0, genres.Length - 2);
                }
                else
                {
                    genres += "не указаны";
                }

                lblGenres.Text = genres;
            }
            catch (Exception ex)
            {
                lblGenres.Text = "Жанры: не загружены";
            }
        }
        private void LoadFilmCollections()
        {
            try
            {
                // Загружаем коллекции пользователя, в которые добавлен этот фильм
                string query = $@"
            SELECT 
                c.COLLECTIONS_ID AS ID,
                c.TITLE AS CollectionName,
                CASE WHEN fc.FILM IS NOT NULL THEN '✓' ELSE '' END AS InCollection
            FROM COLLECTIONS c
            LEFT JOIN FILM_COLLECTION fc ON c.COLLECTIONS_ID = fc.COLLECTION AND fc.FILM = {filmId}
            WHERE c.USER_NAME = '{username}'";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgvUserCollections.DataSource = dt;

                // Настраиваем отображение
                if (dgvUserCollections.Columns.Contains("ID"))
                {
                    dgvUserCollections.Columns["ID"].Visible = false;
                }

                if (dgvUserCollections.Columns.Contains("CollectionName"))
                {
                    dgvUserCollections.Columns["CollectionName"].HeaderText = "Коллекция";
                    dgvUserCollections.Columns["CollectionName"].Width = 250;
                }

                if (dgvUserCollections.Columns.Contains("InCollection"))
                {
                    dgvUserCollections.Columns["InCollection"].HeaderText = "В коллекции";
                    dgvUserCollections.Columns["InCollection"].Width = 100;
                }

                dgvUserCollections.ReadOnly = true;
                dgvUserCollections.AllowUserToAddRows = false;
                dgvUserCollections.AllowUserToDeleteRows = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки коллекций: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ОБРАБОТЧИК ДЛЯ CellContentClick (нужен для дизайнера)
        private void dgvCrew_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Просто вызываем обработчик CellClick
            dgvCrew_CellClick(sender, e);
        }

        // ОБРАБОТЧИК ОДИНАРНОГО КЛИКА ПО ЧЕЛОВЕКУ В СЪЕМОЧНОЙ ГРУППЕ
        private void dgvCrew_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                try
                {
                    if (dgvCrew.Rows[e.RowIndex].Cells["PEOPLE_ID"].Value != null)
                    {
                        int personId = Convert.ToInt32(dgvCrew.Rows[e.RowIndex].Cells["PEOPLE_ID"].Value);
                        string personName = dgvCrew.Rows[e.RowIndex].Cells["PERSON_NAME"].Value?.ToString();

                        // Открываем форму с деталями о человеке
                        FormPersonDetails personForm = new FormPersonDetails(personId);
                        personForm.ShowDialog();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка открытия деталей человека: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Обработчик для коллекций (только просмотр, без действий)
        private void dgvCollections_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Просто выделяем строку, никаких действий не выполняем
            }
        }

        private void bntBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}