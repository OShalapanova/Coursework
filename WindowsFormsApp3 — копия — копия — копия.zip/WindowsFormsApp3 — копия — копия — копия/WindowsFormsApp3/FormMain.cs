﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
            lblDescription.Text = "Добро пожаловать в систему управления кинотекой!\n\n" +
                                 "Здесь вы можете:\n" +
                                 "• Просматривать информацию о фильмах\n" +
                                 "• Создавать свои коллекции\n" +
                                 "• Искать фильмы по различным критериям\n" +
                                 "• Узнавать об актерах и режиссерах";

        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormLogin loginForm = new FormLogin("user");
            if (loginForm.ShowDialog() == DialogResult.OK)
            {
                FormUser userForm = new FormUser(loginForm.Username);
                userForm.Show();
                this.Hide();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormLogin loginForm = new FormLogin("admin");
            if (loginForm.ShowDialog() == DialogResult.OK)
            {
                FormAdmin adminForm = new FormAdmin(loginForm.Username);
                adminForm.Show();
                this.Hide();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormRegister registerForm = new FormRegister();
            registerForm.ShowDialog();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {

        }
    }
}
