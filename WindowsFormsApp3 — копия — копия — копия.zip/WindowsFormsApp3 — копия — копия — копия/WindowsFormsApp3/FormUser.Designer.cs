﻿namespace WindowsFormsApp3
{
    partial class FormUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bntBack = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabFilms = new System.Windows.Forms.TabPage();
            this.dvgFilms = new System.Windows.Forms.DataGridView();
            this.searchPanel = new System.Windows.Forms.Panel();
            this.cmbCountryFilter = new System.Windows.Forms.ComboBox();
            this.lblCountry = new System.Windows.Forms.Label();
            this.cmbGenreFilter = new System.Windows.Forms.ComboBox();
            this.lblGenre = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.tabCollections = new System.Windows.Forms.TabPage();
            this.dvgCollections = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.bntDeleteCollection = new System.Windows.Forms.Button();
            this.bntEditCollection = new System.Windows.Forms.Button();
            this.bntNewCollection = new System.Windows.Forms.Button();
            this.tabControl.SuspendLayout();
            this.tabFilms.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgFilms)).BeginInit();
            this.searchPanel.SuspendLayout();
            this.tabCollections.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgCollections)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bntBack
            // 
            this.bntBack.Location = new System.Drawing.Point(10, 10);
            this.bntBack.Name = "bntBack";
            this.bntBack.Size = new System.Drawing.Size(80, 30);
            this.bntBack.TabIndex = 0;
            this.bntBack.Text = "Назад";
            this.bntBack.UseVisualStyleBackColor = true;
            this.bntBack.Click += new System.EventHandler(this.bntBack_Click);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabFilms);
            this.tabControl.Controls.Add(this.tabCollections);
            this.tabControl.Location = new System.Drawing.Point(10, 50);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(980, 600);
            this.tabControl.TabIndex = 1;
            // 
            // tabFilms
            // 
            this.tabFilms.Controls.Add(this.dvgFilms);
            this.tabFilms.Controls.Add(this.searchPanel);
            this.tabFilms.Location = new System.Drawing.Point(4, 25);
            this.tabFilms.Name = "tabFilms";
            this.tabFilms.Padding = new System.Windows.Forms.Padding(3);
            this.tabFilms.Size = new System.Drawing.Size(972, 571);
            this.tabFilms.TabIndex = 0;
            this.tabFilms.Text = "Фильмы";
            this.tabFilms.UseVisualStyleBackColor = true;
            // 
            // dvgFilms
            // 
            this.dvgFilms.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgFilms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dvgFilms.Location = new System.Drawing.Point(3, 53);
            this.dvgFilms.Name = "dvgFilms";
            this.dvgFilms.RowHeadersWidth = 51;
            this.dvgFilms.RowTemplate.Height = 24;
            this.dvgFilms.Size = new System.Drawing.Size(966, 515);
            this.dvgFilms.TabIndex = 1;
            this.dvgFilms.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvgFilms_CellContentClick);
            // 
            // searchPanel
            // 
            this.searchPanel.Controls.Add(this.cmbCountryFilter);
            this.searchPanel.Controls.Add(this.lblCountry);
            this.searchPanel.Controls.Add(this.cmbGenreFilter);
            this.searchPanel.Controls.Add(this.lblGenre);
            this.searchPanel.Controls.Add(this.txtSearch);
            this.searchPanel.Controls.Add(this.lblSearch);
            this.searchPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.searchPanel.Location = new System.Drawing.Point(3, 3);
            this.searchPanel.Name = "searchPanel";
            this.searchPanel.Size = new System.Drawing.Size(966, 50);
            this.searchPanel.TabIndex = 0;
            this.searchPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.searchPanel_Paint);
            // 
            // cmbCountryFilter
            // 
            this.cmbCountryFilter.FormattingEnabled = true;
            this.cmbCountryFilter.Location = new System.Drawing.Point(520, 14);
            this.cmbCountryFilter.Name = "cmbCountryFilter";
            this.cmbCountryFilter.Size = new System.Drawing.Size(121, 24);
            this.cmbCountryFilter.TabIndex = 5;
            this.cmbCountryFilter.SelectedIndexChanged += new System.EventHandler(this.cmbCountryFilter_SelectedIndexChanged);
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Location = new System.Drawing.Point(413, 14);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(55, 16);
            this.lblCountry.TabIndex = 4;
            this.lblCountry.Text = "Страна";
            this.lblCountry.Click += new System.EventHandler(this.lblCountry_Click);
            // 
            // cmbGenreFilter
            // 
            this.cmbGenreFilter.FormattingEnabled = true;
            this.cmbGenreFilter.Location = new System.Drawing.Point(257, 14);
            this.cmbGenreFilter.Name = "cmbGenreFilter";
            this.cmbGenreFilter.Size = new System.Drawing.Size(121, 24);
            this.cmbGenreFilter.TabIndex = 3;
            this.cmbGenreFilter.SelectedIndexChanged += new System.EventHandler(this.cmbGenreFilter_SelectedIndexChanged);
            // 
            // lblGenre
            // 
            this.lblGenre.AutoSize = true;
            this.lblGenre.Location = new System.Drawing.Point(187, 14);
            this.lblGenre.Name = "lblGenre";
            this.lblGenre.Size = new System.Drawing.Size(44, 16);
            this.lblGenre.TabIndex = 2;
            this.lblGenre.Text = "Жанр";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(69, 8);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(100, 22);
            this.txtSearch.TabIndex = 1;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(16, 11);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(47, 16);
            this.lblSearch.TabIndex = 0;
            this.lblSearch.Text = "Поиск";
            // 
            // tabCollections
            // 
            this.tabCollections.Controls.Add(this.dvgCollections);
            this.tabCollections.Controls.Add(this.panel1);
            this.tabCollections.Location = new System.Drawing.Point(4, 25);
            this.tabCollections.Name = "tabCollections";
            this.tabCollections.Padding = new System.Windows.Forms.Padding(3);
            this.tabCollections.Size = new System.Drawing.Size(972, 571);
            this.tabCollections.TabIndex = 1;
            this.tabCollections.Text = "Мои коллекции";
            this.tabCollections.UseVisualStyleBackColor = true;
            // 
            // dvgCollections
            // 
            this.dvgCollections.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgCollections.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dvgCollections.Location = new System.Drawing.Point(3, 58);
            this.dvgCollections.Name = "dvgCollections";
            this.dvgCollections.RowHeadersWidth = 51;
            this.dvgCollections.RowTemplate.Height = 24;
            this.dvgCollections.Size = new System.Drawing.Size(966, 510);
            this.dvgCollections.TabIndex = 1;
            this.dvgCollections.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvgCollections_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.bntDeleteCollection);
            this.panel1.Controls.Add(this.bntEditCollection);
            this.panel1.Controls.Add(this.bntNewCollection);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(966, 55);
            this.panel1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button1.Location = new System.Drawing.Point(429, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 38);
            this.button1.TabIndex = 3;
            this.button1.Text = "Добавить фильм";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bntDeleteCollection
            // 
            this.bntDeleteCollection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.bntDeleteCollection.Location = new System.Drawing.Point(331, 11);
            this.bntDeleteCollection.Name = "bntDeleteCollection";
            this.bntDeleteCollection.Size = new System.Drawing.Size(92, 38);
            this.bntDeleteCollection.TabIndex = 2;
            this.bntDeleteCollection.Text = "Удалить";
            this.bntDeleteCollection.UseVisualStyleBackColor = false;
            this.bntDeleteCollection.Click += new System.EventHandler(this.bntDeleteCollection_Click);
            // 
            // bntEditCollection
            // 
            this.bntEditCollection.Location = new System.Drawing.Point(161, 11);
            this.bntEditCollection.Name = "bntEditCollection";
            this.bntEditCollection.Size = new System.Drawing.Size(164, 38);
            this.bntEditCollection.TabIndex = 1;
            this.bntEditCollection.Text = "Редактирование";
            this.bntEditCollection.UseVisualStyleBackColor = true;
            this.bntEditCollection.Click += new System.EventHandler(this.bntEditCollection_Click);
            // 
            // bntNewCollection
            // 
            this.bntNewCollection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bntNewCollection.Location = new System.Drawing.Point(3, 11);
            this.bntNewCollection.Name = "bntNewCollection";
            this.bntNewCollection.Size = new System.Drawing.Size(152, 38);
            this.bntNewCollection.TabIndex = 0;
            this.bntNewCollection.Text = "Новая коллекция";
            this.bntNewCollection.UseVisualStyleBackColor = false;
            this.bntNewCollection.Click += new System.EventHandler(this.bntNewCollection_Click);
            // 
            // FormUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp3.Properties.Resources.unnamed;
            this.ClientSize = new System.Drawing.Size(982, 653);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.bntBack);
            this.Name = "FormUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormUser";
            this.tabControl.ResumeLayout(false);
            this.tabFilms.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dvgFilms)).EndInit();
            this.searchPanel.ResumeLayout(false);
            this.searchPanel.PerformLayout();
            this.tabCollections.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dvgCollections)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bntBack;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabFilms;
        private System.Windows.Forms.TabPage tabCollections;
        private System.Windows.Forms.Panel searchPanel;
        private System.Windows.Forms.ComboBox cmbCountryFilter;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.ComboBox cmbGenreFilter;
        private System.Windows.Forms.Label lblGenre;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.DataGridView dvgFilms;
        private System.Windows.Forms.DataGridView dvgCollections;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bntDeleteCollection;
        private System.Windows.Forms.Button bntEditCollection;
        private System.Windows.Forms.Button bntNewCollection;
        private System.Windows.Forms.Button button1;
    }
}