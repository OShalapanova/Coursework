﻿using System;
using System.Windows.Forms;
using FirebirdSql.Data.FirebirdClient;

namespace WindowsFormsApp3
{
    public partial class FormEditCountry : Form
    {
        private string adminUsername;

        public FormEditCountry(string adminUsername)
        {
            InitializeComponent();
            this.adminUsername = adminUsername;
            Text = "Добавить страну";
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCode.Text) || string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Заполните все поля", "Ошибка");
                return;
            }

            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new FbCommand(@"
                        INSERT INTO COUNTRIES (COUNTRY_CODE, COUNTRY_NAME, CREATED_ADMIN)
                        VALUES (@code, @name, @admin)", conn);
                    cmd.Parameters.AddWithValue("@code", txtCode.Text.Trim());
                    cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                    cmd.Parameters.AddWithValue("@admin", adminUsername);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Страна добавлена!", "Успех");
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}