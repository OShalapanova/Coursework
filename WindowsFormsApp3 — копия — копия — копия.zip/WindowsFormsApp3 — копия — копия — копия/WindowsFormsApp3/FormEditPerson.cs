﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormEditPerson : Form
    {
        private string adminUsername;
        private int? personId;
        public FormEditPerson(string adminUsername, int? personId = null)
        {
            InitializeComponent();
            this.adminUsername = adminUsername;
            this.personId = personId;
            LoadCountries();
            if (personId.HasValue)
            {
                LoadPersonData(personId.Value);
                Text = "Редактировать персону";
            }
            else
            {
                Text = "Добавить персону";
                dtpBirthYear.Value = DateTime.Now.AddYears(-30); // по умолчанию — 30 лет назад
            }
        }
        private void LoadCountries()
        {
            try
            {
                string query = "SELECT COUNTRY_CODE, COUNTRY_NAME FROM COUNTRIES ORDER BY COUNTRY_NAME";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                cmbCountry.DisplayMember = "COUNTRY_NAME";
                cmbCountry.ValueMember = "COUNTRY_CODE";
                cmbCountry.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки стран: {ex.Message}", "Ошибка");
            }
        }

        private void LoadPersonData(int id)
        {
            try
            {
                string query = "SELECT * FROM PEOPLE WHERE PEOPLE_ID = @id";
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    using (var cmd = new FbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        DataTable dt = new DataTable();
                        dt.Load(cmd.ExecuteReader());
                        if (dt.Rows.Count > 0)
                        {
                            var row = dt.Rows[0];
                            txtLastName.Text = row["LAST_NAME"]?.ToString() ?? "";
                            txtFirstName.Text = row["FIRST_NAME"]?.ToString() ?? "";
                            txtPatronymic.Text = row["PATRONYMIC"]?.ToString() ?? "";
                            if (row["BIRTH_YEAR"] != DBNull.Value)
                                dtpBirthYear.Value = Convert.ToDateTime(row["BIRTH_YEAR"]);
                            if (row["COUNTRY_CODE"] != DBNull.Value)
                                cmbCountry.SelectedValue = row["COUNTRY_CODE"].ToString();
                            txtBiography.Text = row["BIOGRAPHY"]?.ToString() ?? "";
                            if (row["PHOTO"] != DBNull.Value)
                                pbPhoto.Image = DatabaseHelper.GetImageFromBytes((byte[])row["PHOTO"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки персоны: {ex.Message}", "Ошибка");
            }
        }

        private void btnLoadPhoto_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        pbPhoto.Image = Image.FromFile(dlg.FileName);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Не удалось загрузить изображение:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                MessageBox.Show("Укажите имя и фамилию", "Ошибка");
                return;
            }

            byte[] photoBytes = null;
            if (pbPhoto.Image != null)
            {
                try
                {
                    // 🛡️ Создаем КОПИЮ изображения
                    using (Bitmap clone = new Bitmap(pbPhoto.Image))
                    {
                        using (MemoryStream ms = new MemoryStream())
                        {
                            clone.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                            photoBytes = ms.ToArray();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка сохранения фото: {ex.Message}", "Ошибка");
                    return; // Прерываем сохранение
                }
            }

            string countryCode = cmbCountry.SelectedValue?.ToString() ?? "";

            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                FbCommand cmd;
                if (personId.HasValue)
                {
                    // UPDATE
                    cmd = new FbCommand(@"
                        UPDATE PEOPLE SET
                            LAST_NAME = @lastName,
                            FIRST_NAME = @firstName,
                            PATRONYMIC = @patronymic,
                            BIRTH_YEAR = @birth,
                            COUNTRY_CODE = @country,
                            BIOGRAPHY = @bio,
                            PHOTO = @photo
                        WHERE PEOPLE_ID = @id", conn);
                    cmd.Parameters.AddWithValue("@id", personId.Value);
                }
                else
                {
                    // INSERT
                    cmd = new FbCommand(@"
                        INSERT INTO PEOPLE (LAST_NAME, FIRST_NAME, PATRONYMIC, BIRTH_YEAR, COUNTRY_CODE, BIOGRAPHY, PHOTO, CREATED_ADMIN)
                        VALUES (@lastName, @firstName, @patronymic, @birth, @country, @bio, @photo, @admin)", conn);
                    cmd.Parameters.AddWithValue("@admin", adminUsername);
                }

                cmd.Parameters.AddWithValue("@lastName", txtLastName.Text.Trim());
                cmd.Parameters.AddWithValue("@firstName", txtFirstName.Text.Trim());
                cmd.Parameters.AddWithValue("@patronymic", txtPatronymic.Text.Trim());
                cmd.Parameters.AddWithValue("@birth", dtpBirthYear.Value.Date);
                cmd.Parameters.AddWithValue("@country", countryCode);
                cmd.Parameters.AddWithValue("@bio", txtBiography.Text);
                cmd.Parameters.AddWithValue("@photo", photoBytes ?? (object)DBNull.Value);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(personId.HasValue ? "Персона обновлена!" : "Персона добавлена!", "Успех");
                    DialogResult = DialogResult.OK;
                    Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
