﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;

namespace WindowsFormsApp3
{
    public partial class FormAdmin : Form
    {
        private string username;
        private DataGridView currentDgv;
        private string currentTable;
        public FormAdmin(string username)
        {
            this.username = username;
            InitializeComponent();
            this.Text = $"Кинотека - Администратор: {username}";
            SetupDataGridViews();
            if (tabControl1 != null)
            {
                tabControl1.SelectedIndexChanged += tabControl1_SelectedIndexChanged;

                // Или привязка для отдельных вкладок:
                // tabFilms.Click += tabFilms_Click;
                // tabPeople.Click += tabPeople_Click;
                // и т.д.
            }

            currentDgv = dgvFilms;
            currentTable = "FILMS";
            LoadTableData(currentTable, dgvFilms);
        }
        private void SetupDataGridViews()
        {
            DataGridView[] grids = { dgvFilms, dgvPeople, dgvCountries, dgvGenres, dgvRoles, dgvAdmins };
            foreach (var dgv in grids)
            {
                if (dgv != null)
                {
                    dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    dgv.ReadOnly = true;
                    dgv.Visible = false;
                }
            }

            dgvFilms.Visible = true;

            // Связываем теги с реальными названиями таблиц
            dgvFilms.Tag = "FILMS";
            dgvPeople.Tag = "PEOPLE";
            dgvCountries.Tag = "COUNTRIES";
            dgvGenres.Tag = "GENRES";   // ← ДОБАВЛЕНО!
            dgvRoles.Tag = "ROLES";
            dgvAdmins.Tag = "ADMINS";
        }

        private void tsbAdd_Click(object sender, EventArgs e)
        {
            if (currentTable == "FILMS")
            {
                var form = new FormEditFilm(username);
                if (form.ShowDialog() == DialogResult.OK) LoadTableData("FILMS", dgvFilms);
            }
            else if (currentTable == "PEOPLE")
            {
                var form = new FormEditPerson(username);
                if (form.ShowDialog() == DialogResult.OK) LoadTableData("PEOPLE", dgvPeople);
            }
            else if (currentTable == "COUNTRIES")
            {
                var form = new FormEditCountry(username);
                if (form.ShowDialog() == DialogResult.OK) LoadTableData("COUNTRIES", dgvCountries);
            }
            else if (currentTable == "GENRES")
            {
                var form = new FormEditGenre(username);
                if (form.ShowDialog() == DialogResult.OK) LoadTableData("GENRES", dgvGenres);
            }
            else if (currentTable == "ROLES")
            {
                var form = new FormEditRole(username);
                if (form.ShowDialog() == DialogResult.OK) LoadTableData("ROLES", dgvRoles);
            }
            else if (currentTable == "ADMINS")
            {
                // Для добавления передаем только текущего администратора (username)
                var form = new FormEditAdmin(username);
                if (form.ShowDialog() == DialogResult.OK) LoadTableData("ADMINS", dgvAdmins);
            }
        }
        private void tsbEdit_Click(object sender, EventArgs e)
        {
            if (currentDgv == null || currentDgv.SelectedRows.Count == 0) return;

            try
            {
                DataRowView rowView = currentDgv.SelectedRows[0].DataBoundItem as DataRowView;
                if (rowView == null) return;

                if (currentTable == "FILMS")
                {
                    int filmId = (int)rowView.Row["FILM_ID"];
                    var form = new FormEditFilm(username, filmId);
                    if (form.ShowDialog() == DialogResult.OK) LoadTableData("FILMS", dgvFilms);
                }
                else if (currentTable == "PEOPLE")
                {
                    int peopleId = (int)rowView.Row["PEOPLE_ID"];
                    var form = new FormEditPerson(username, peopleId);
                    if (form.ShowDialog() == DialogResult.OK) LoadTableData("PEOPLE", dgvPeople);
                }
                else if (currentTable == "ADMINS")
                {
                    string login = rowView.Row["LOGIN"].ToString();
                    string pass = rowView.Row["PASWORD"].ToString();
                    string email = rowView.Row["EMAIL"].ToString();
                    var form = new FormEditAdmin(username, login, pass, email);
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        LoadTableData("ADMINS", dgvAdmins);
                        MessageBox.Show("Админ обновлён", "Успех");
                    }
                }
                else
                {
                    MessageBox.Show("Редактирование этой таблицы запрещено.", "Инфо");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
            }
        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            if (currentDgv == null || currentDgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись для удаления", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                DataRowView rowView = currentDgv.SelectedRows[0].DataBoundItem as DataRowView;
                if (rowView == null) return;

                string pkColumn = GetPrimaryKeyColumn(currentTable);
                if (string.IsNullOrEmpty(pkColumn))
                {
                    MessageBox.Show("Не удалось определить первичный ключ", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                object pkValue = rowView.Row[pkColumn];
                string displayValue = GetDisplayValue(rowView.Row);

                DialogResult result = MessageBox.Show(
                    $"Удалить запись:\n{displayValue}?",
                    "Подтверждение удаления",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string valueStr = (pkValue is string) ? $"'{pkValue}'" : pkValue.ToString();
                    string deleteQuery = $"DELETE FROM {currentTable} WHERE {pkColumn} = {valueStr}";

                    int affected = DatabaseHelper.ExecuteNonQuery(deleteQuery);
                    if (affected > 0)
                    {
                        MessageBox.Show("Запись удалена", "Успех",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadTableData(currentTable, currentDgv);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tsbRefresh_Click(object sender, EventArgs e)
        {
            if (currentTable != null)
            {
                LoadTableData(currentTable, currentDgv);
                MessageBox.Show("Данные обновлены", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void LoadTableData(string tableName, DataGridView dgv)
        {
            try
            {
                string query = $"SELECT * FROM {tableName}";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgv.DataSource = dt;

                // Настройка заголовков для удобства чтения
                if (tableName == "ADMINS" && dgv.Columns.Contains("CREATE_ADMIN"))
                {
                    dgv.Columns["CREATE_ADMIN"].HeaderText = "Создал/Обновил";
                    dgv.Columns["LOGIN"].HeaderText = "Логин";
                    dgv.Columns["PASWORD"].HeaderText = "Пароль";
                    dgv.Columns["EMAIL"].HeaderText = "Email";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void tsbBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormMain().Show();
        }
        private string GetPrimaryKeyColumn(string tableName)
        {
            switch (tableName.ToUpper())
            {
                case "FILMS": return "FILM_ID";
                case "PEOPLE": return "PEOPLE_ID";
                case "COUNTRIES": return "COUNTRY_CODE";
                case "GENRES": return "GENRE_NAME";
                case "ROLES": return "ROLE_NAME";
                case "ADMINS": return "LOGIN";
                default: return "";
            }
        }
        private string GetDisplayValue(DataRow row)
        {
            if (row.Table.Columns.Contains("TITLE"))
                return row["TITLE"].ToString();
            else if (row.Table.Columns.Contains("NAME"))
                return row["NAME"].ToString();
            else if (row.Table.Columns.Contains("FIRST_NAME"))
                return $"{row["FIRST_NAME"]} {row["LAST_NAME"]}";
            else if (row.Table.Columns.Contains("LOGIN"))
                return row["LOGIN"].ToString();
            else
                return row[0].ToString();
        }
        private void ShowTable(string tableName, DataGridView dgv)
        {
            dgvFilms.Visible = false;
            dgvPeople.Visible = false;
            dgvCountries.Visible = false;
            dgvGenres.Visible = false;
            dgvRoles.Visible = false;
            dgvAdmins.Visible = false;

            // Показываем выбранную
            dgv.Visible = true;
            currentDgv = dgv;
            currentTable = tableName;
            LoadTableData(tableName, currentDgv);

        }
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab != null)
            {
                string tableName = tabControl1.SelectedTab.Text;
                switch (tableName)
                {
                    case "FILMS": ShowTable("FILMS", dgvFilms); break;
                    case "PEOPLE": ShowTable("PEOPLE", dgvPeople); break;
                    case "COUNTRIES": ShowTable("COUNTRIES", dgvCountries); break;
                    case "GENRES": ShowTable("GENRES", dgvGenres); break;
                    case "ROLES": ShowTable("ROLES", dgvRoles); break;
                    case "ADMINS": ShowTable("ADMINS", dgvAdmins); break;
                }

                // Отключаем редактирование для COUNTRIES, GENRES, ROLES
                tsbEdit.Enabled = (currentTable == "FILMS" || currentTable == "PEOPLE" || currentTable == "ADMINS");
            }
        }

        private void dgvFilms_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
