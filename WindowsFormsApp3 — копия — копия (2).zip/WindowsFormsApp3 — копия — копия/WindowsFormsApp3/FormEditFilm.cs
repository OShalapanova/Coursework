﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormEditFilm : Form
    {
        private string username;
        private int? filmId;
        public FormEditFilm(string username, int? filmId = null)
        {
            InitializeComponent();
            this.username = username;
            this.filmId = filmId;
            LoadGenres();
            LoadCountries();

            if (filmId.HasValue)
            {
                LoadFilmData(filmId.Value);
                this.Text = "Редактировать фильм";
            }
            else
            {
                this.Text = "Добавить фильм";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LoadCountries()
        {
            string query = "SELECT COUNTRY_CODE, COUNTRY_NAME FROM COUNTRIES ORDER BY COUNTRY_NAME";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            cmbCountry.DisplayMember = "COUNTRY_NAME";
            cmbCountry.ValueMember = "COUNTRY_CODE";
            cmbCountry.DataSource = dt;
        }

        private void LoadFilmData(int filmId)
        {
            string query = $"SELECT * FROM FILMS WHERE FILM_ID = {filmId}";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            if (dt.Rows.Count > 0)
            {
                var row = dt.Rows[0];
                txtTitle.Text = row["TITLE"].ToString();
                nudYear.Value = Convert.ToInt32(row["RELESE_YEAR"]);

                // Загружаем тип продукта (жанр) в comboBox1
                if (row["PRODUCT_TYPE"] != DBNull.Value)
                {
                    string productType = row["PRODUCT_TYPE"].ToString();
                    // Устанавливаем выбранное значение в comboBox1
                    foreach (DataRowView item in comboBox1.Items)
                    {
                        if (item["GENRE_NAME"].ToString() == productType)
                        {
                            comboBox1.SelectedItem = item;
                            break;
                        }
                    }
                }

                txtDuration.Text = row["DURATION"]?.ToString() ?? "";
                txtRating.Text = row["RATING"]?.ToString() ?? "";
                txtDescription.Text = row["DESCRIPTION"]?.ToString() ?? "";

                if (row["COUNTRY_CODE"] != DBNull.Value)
                {
                    cmbCountry.SelectedValue = row["COUNTRY_CODE"].ToString();
                }

                if (row["POSTER"] != DBNull.Value)
                {
                    byte[] bytes = (byte[])row["POSTER"];
                    pbPoster.Image = DatabaseHelper.GetImageFromBytes(bytes);
                }
            }
        }

        private void btnLoadPoster_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        pbPoster.Image = Image.FromFile(dlg.FileName);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Не удалось загрузить изображение:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Введите название фильма", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(nudYear.Text, out int releaseYear) || releaseYear < 1888)
            {
                MessageBox.Show("Год выпуска должен быть числом ≥ 1888", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(txtDuration.Text, out int duration) || duration <= 0)
            {
                MessageBox.Show("Длительность должна быть положительным числом", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!decimal.TryParse(txtRating.Text, out decimal rating) || rating < 0 || rating > 10)
            {
                MessageBox.Show("Рейтинг должен быть числом от 0 до 10", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Получаем выбранную страну
            string countryCode = "";
            if (cmbCountry.SelectedValue != null)
                countryCode = cmbCountry.SelectedValue.ToString();

            // Получаем выбранный жанр ИЗ COMBOBOX (а не из Text)
            string genre = "";
            if (comboBox1.SelectedValue != null)
                genre = comboBox1.SelectedValue.ToString();
            else if (!string.IsNullOrEmpty(comboBox1.Text))
                genre = comboBox1.Text.Trim();

            if (string.IsNullOrEmpty(genre))
            {
                MessageBox.Show("Выберите жанр фильма", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox1.Focus();
                return;
            }

            byte[] posterBytes = null;
            if (pbPoster.Image != null)
            {
                try
                {
                    using (Bitmap clone = new Bitmap(pbPoster.Image))
                    {
                        using (MemoryStream ms = new MemoryStream())
                        {
                            clone.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                            posterBytes = ms.ToArray();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка сохранения постера: {ex.Message}", "Ошибка");
                    return;
                }
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                FbCommand cmd;

                if (filmId.HasValue)
                {
                    // UPDATE
                    cmd = new FbCommand(@"
UPDATE FILMS 
SET TITLE = :title,
    RELESE_YEAR = :release_year,
    PRODUCT_TYPE = :type,
    COUNTRY_CODE = :country,
    DURATION = :duration,
    RATING = :rating,
    DESCRIPTION = :desc,
    POSTER = :poster,
    CREATED_ADMIN = :created_admin
WHERE FILM_ID = :film_id", conn);

                    cmd.Parameters.AddWithValue(":film_id", filmId.Value);
                }
                else
                {
                    // INSERT
                    cmd = new FbCommand(@"
INSERT INTO FILMS 
(TITLE, RELESE_YEAR, PRODUCT_TYPE, COUNTRY_CODE, DURATION, RATING, DESCRIPTION, POSTER, CREATED_ADMIN)
VALUES 
(:title, :release_year, :type, :country, :duration, :rating, :desc, :poster, :created_admin)", conn);
                }

                // Параметры
                cmd.Parameters.AddWithValue(":title", txtTitle.Text.Trim());
                cmd.Parameters.AddWithValue(":release_year", releaseYear);
                cmd.Parameters.AddWithValue(":type", genre);
                cmd.Parameters.AddWithValue(":created_admin", username);

                if (!string.IsNullOrEmpty(countryCode))
                    cmd.Parameters.AddWithValue(":country", countryCode);
                else
                    cmd.Parameters.AddWithValue(":country", DBNull.Value);

                cmd.Parameters.AddWithValue(":duration", duration);
                cmd.Parameters.AddWithValue(":rating", rating);

                if (!string.IsNullOrEmpty(txtDescription.Text))
                    cmd.Parameters.AddWithValue(":desc", txtDescription.Text.Trim());
                else
                    cmd.Parameters.AddWithValue(":desc", DBNull.Value);

                if (posterBytes != null)
                    cmd.Parameters.AddWithValue(":poster", posterBytes);
                else
                    cmd.Parameters.AddWithValue(":poster", DBNull.Value);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Фильм успешно сохранён!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (FbException fbEx)
                {
                    MessageBox.Show($"Ошибка SQL:\n{cmd.CommandText}\n\nОшибка: {fbEx.Message}",
                        "Ошибка базы данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка сохранения:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadGenres()
        {
            string query = "SELECT GENRE_NAME FROM GENRES ORDER BY GENRE_NAME";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            comboBox1.DisplayMember = "GENRE_NAME";
            comboBox1.ValueMember = "GENRE_NAME";
            comboBox1.DataSource = dt;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}