﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormPersonDetails : Form
    {
        private int personId;
        public FormPersonDetails(int personId)
        {
            InitializeComponent();
            this.personId = personId;
            LoadPersonDetails();
        }
        private void LoadPersonDetails()
        {
            try
            {
                // 1. Загрузка основной информации
                string query = $@"
                    SELECT 
                        p.FIRST_NAME,
                        p.LAST_NAME,
                        p.PATRONYMIC,
                        p.BIRTH_YEAR,
                        p.BIOGRAPHY,
                        p.PHOTO,
                        c.COUNTRY_NAME
                    FROM PEOPLE p
                    LEFT JOIN COUNTRIES c ON p.COUNTRY_CODE = c.COUNTRY_CODE
                    WHERE p.PEOPLE_ID = {personId}";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);

                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];

                    // Формируем полное имя
                    string firstName = row["FIRST_NAME"].ToString();
                    string lastName = row["LAST_NAME"].ToString();
                    string patronymic = row["PATRONYMIC"] != DBNull.Value ? row["PATRONYMIC"].ToString() : "";

                    string fullName = $"{lastName} {firstName}";
                    if (!string.IsNullOrEmpty(patronymic))
                    {
                        fullName += $" {patronymic}";
                    }

                    lblName.Text = fullName;

                    // Дата рождения
                    if (row["BIRTH_YEAR"] != DBNull.Value)
                    {
                        DateTime birthDate = Convert.ToDateTime(row["BIRTH_YEAR"]);
                        lblBirthYear.Text = $"Дата рождения: {birthDate:dd.MM.yyyy}";
                    }
                    else
                    {
                        lblBirthYear.Text = "Дата рождения: не указана";
                    }

                    // Страна
                    lblCountry.Text = $"Страна: {row["COUNTRY_NAME"]}";

                    // Фото
                    if (row["PHOTO"] != DBNull.Value)
                    {
                        byte[] imageBytes = (byte[])row["PHOTO"];
                        pbPhoto.Image = DatabaseHelper.GetImageFromBytes(imageBytes);
                    }

                    // Биография
                    if (row["BIOGRAPHY"] != DBNull.Value)
                    {
                        txtBiography.Text = row["BIOGRAPHY"].ToString();
                    }
                    else
                    {
                        txtBiography.Text = "Биография отсутствует";
                    }
                }

                // 2. Загрузка фильмов
                LoadPersonFilms();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadPersonFilms()
        {
            try
            {
                string query = $@"
                    SELECT 
                        f.FILM_ID as 'ID',
                        f.TITLE as 'Название фильма',
                        f.RELESE_YEAR as 'Год',
                        r.ROLE_NAME as 'Роль',
                        fc.ROLE_FILM as 'Описание роли'
                    FROM FILM_CREW fc
                    JOIN FILMS f ON fc.FILM_ID = f.FILM_ID
                    JOIN ROLES r ON fc.TITLE_ROLE = r.ROLE_NAME
                    WHERE fc.PEOPLE_ID = {personId}
                    ORDER BY f.RELESE_YEAR DESC";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgvFilms.DataSource = dt;

                // Скрываем колонку ID
                if (dgvFilms.Columns.Contains("ID"))
                {
                    dgvFilms.Columns["ID"].Visible = false;
                }

                lblFilmCount.Text = $"Фильмов: {dt.Rows.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки фильмов: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bntBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvFilms_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                if (dgvFilms.Rows[e.RowIndex].Cells["ID"].Value != null)
                {
                    int filmId = Convert.ToInt32(dgvFilms.Rows[e.RowIndex].Cells["ID"].Value);
                    string filmName = dgvFilms.Rows[e.RowIndex].Cells["Название фильма"].Value.ToString();

                    MessageBox.Show($"Открыть детали фильма: {filmName}\nID: {filmId}",
                        "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Для реального использования раскомментируйте:
                    // FormFilmDetails filmForm = new FormFilmDetails(filmId, "");
                    // filmForm.ShowDialog();
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
    
}
