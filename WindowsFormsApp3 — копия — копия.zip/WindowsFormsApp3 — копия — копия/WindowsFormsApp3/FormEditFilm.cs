﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp3
{
    public partial class FormEditFilm : Form
    {
        private string username;
        private int? filmId;
        public FormEditFilm(string username, int? filmId = null)
        {
            InitializeComponent();
            username = username;
            filmId = filmId;
            LoadCountries();
            if (filmId.HasValue)
            {
                LoadFilmData(filmId.Value);
                this.Text = "Редактировать фильм";
            }
            else
            {
                this.Text = "Добавить фильм";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void LoadCountries()
        {
            string query = "SELECT COUNTRY_CODE, COUNTRY_NAME FROM COUNTRIES ORDER BY COUNTRY_NAME";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            cmbCountry.DisplayMember = "COUNTRY_NAME";
            cmbCountry.ValueMember = "COUNTRY_CODE";
            cmbCountry.DataSource = dt;
        }

        private void LoadFilmData(int filmId)
        {
            string query = $"SELECT * FROM FILMS WHERE FILM_ID = {filmId}";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            if (dt.Rows.Count > 0)
            {
                var row = dt.Rows[0];
                txtTitle.Text = row["TITLE"].ToString();
                nudYear.Value = Convert.ToInt32(row["RELESE_YEAR"]);
                txtType.Text = row["PRODUCT_TYPE"].ToString();
                txtDuration.Text = row["DURATION"]?.ToString() ?? "";
                txtRating.Text = row["RATING"]?.ToString() ?? "";
                txtDescription.Text = row["DESCRIPTION"]?.ToString() ?? "";

                if (row["COUNTRY_CODE"] != DBNull.Value)
                {
                    cmbCountry.SelectedValue = row["COUNTRY_CODE"].ToString();
                }

                if (row["POSTER"] != DBNull.Value)
                {
                    byte[] bytes = (byte[])row["POSTER"];
                    pbPoster.Image = DatabaseHelper.GetImageFromBytes(bytes);
                }
            }
        }

        private void btnLoadPoster_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        pbPoster.Image = Image.FromFile(dlg.FileName);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Не удалось загрузить изображение:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Введите название фильма", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(nudYear.Text, out int releaseYear) || releaseYear < 1888)
            {
                MessageBox.Show("Год выпуска должен быть числом ≥ 1888", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(txtDuration.Text, out int duration) || duration <= 0)
            {
                MessageBox.Show("Длительность должна быть положительным числом", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!decimal.TryParse(txtRating.Text, out decimal rating) || rating < 0 || rating > 10)
            {
                MessageBox.Show("Рейтинг должен быть числом от 0 до 10", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string countryCode = "";
            if (cmbCountry.SelectedValue != null)
                countryCode = cmbCountry.SelectedValue.ToString();

            byte[] posterBytes = null;
            if (pbPoster.Image != null)
            {
                using (var ms = new MemoryStream())
                {
                    pbPoster.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    posterBytes = ms.ToArray();
                }
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                FbCommand cmd;

                if (filmId.HasValue)
                {
                    cmd = new FbCommand(@"
                        UPDATE FILMS SET
                            TITLE = @title,
                            RELESE_YEAR = @year,
                            PRODUCT_TYPE = @type,
                            COUNTRY_CODE = @country,
                            DURATION = @duration,
                            RATING = @rating,
                            DESCRIPTION = @desc,
                            POSTER = @poster
                        WHERE FILM_ID = @id", conn);
                    cmd.Parameters.AddWithValue("@id", filmId.Value);
                }
                else
                {
                    cmd = new FbCommand(@"
                        INSERT INTO FILMS (TITLE, RELESE_YEAR, PRODUCT_TYPE, COUNTRY_CODE, DURATION, RATING, DESCRIPTION, POSTER, CREATED_ADMIN)
                        VALUES (@title, @year, @type, @country, @duration, @rating, @desc, @poster, @admin)", conn);
                    cmd.Parameters.AddWithValue("@admin", username);
                }

                cmd.Parameters.AddWithValue("@title", txtTitle.Text.Trim());
                cmd.Parameters.AddWithValue("@year", releaseYear);
                cmd.Parameters.AddWithValue("@type", txtType.Text.Trim());
                cmd.Parameters.AddWithValue("@country", countryCode);
                cmd.Parameters.AddWithValue("@duration", duration);
                cmd.Parameters.AddWithValue("@rating", rating);
                cmd.Parameters.AddWithValue("@desc", txtDescription.Text);
                cmd.Parameters.AddWithValue("@poster", posterBytes ?? (object)DBNull.Value);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Фильм успешно сохранён!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка сохранения:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
