﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;

namespace WindowsFormsApp3
{
    public partial class FormAdmin : Form
    {
        private string username;
        private DataGridView currentDgv;
        private string currentTable;
        public FormAdmin(string username)
        {
            this.username = username;
            InitializeComponent();
            this.Text = $"Кинотека - Администратор: {username}";
            SetupDataGridViews();
            if (tabControl1 != null)
            {
                tabControl1.SelectedIndexChanged += tabControl1_SelectedIndexChanged;

                // Или привязка для отдельных вкладок:
                // tabFilms.Click += tabFilms_Click;
                // tabPeople.Click += tabPeople_Click;
                // и т.д.
            }

            currentDgv = dgvFilms;
            currentTable = "FILMS";
            LoadTableData(currentTable);
        }
        private void SetupDataGridViews()
        {
            DataGridView[] grids = { dgvFilms, dgvPeople, dgvCountries, dgvGenres, dgvRoles, dgvAdmins };
            foreach (var dgv in grids)
            {
                if (dgv != null)
                {
                    dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    dgv.ReadOnly = true;
                    dgv.Visible = false;
                }
            }

            dgvFilms.Visible = true;

            // Связываем теги с реальными названиями таблиц
            dgvFilms.Tag = "FILMS";
            dgvPeople.Tag = "PEOPLE";
            dgvCountries.Tag = "COUNTRIES";
            dgvGenres.Tag = "GENRES";
            dgvRoles.Tag = "ROLES";
            dgvAdmins.Tag = "ADMINS";

        }

        private void tsbAdd_Click(object sender, EventArgs e)
        {
            if (currentTable == null)
            {
                MessageBox.Show("Выберите таблицу", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (currentTable == "FILMS")
            {
                var form = new FormEditFilm(username);
                if (form.ShowDialog() == DialogResult.OK)
                {
                    LoadTableData("FILMS");
                    MessageBox.Show("Запись добавлена", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else if (currentTable == "PEOPLE")
            {
                // Пока используем FormEditRecord, но в будущем заменишь на FormEditPerson
                var form = new FormEditRecord(currentTable, null, username);
                if (form.ShowDialog() == DialogResult.OK)
                {
                    LoadTableData("PEOPLE");
                    MessageBox.Show("Запись добавлена", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else if (currentTable == "COUNTRIES" || currentTable == "GENRES" || currentTable == "ROLES" || currentTable == "ADMINS")
            {
                var form = new FormEditRecord(currentTable, null, username);
                if (form.ShowDialog() == DialogResult.OK)
                {
                    LoadTableData(currentTable);
                    MessageBox.Show("Запись добавлена", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

        }

        private void tsbEdit_Click(object sender, EventArgs e)
        {
            if (currentDgv == null || currentDgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись", "Инфо", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                DataRowView rowView = currentDgv.SelectedRows[0].DataBoundItem as DataRowView;
                if (rowView == null) return;

                if (currentTable == "FILMS")
                {
                    int filmId = (int)rowView.Row["FILM_ID"];
                    var form = new FormEditFilm(username, filmId); // ← ИСПОЛЬЗУЕМ FormEditFilm
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        LoadTableData("FILMS");
                        MessageBox.Show("Запись обновлена", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else if (currentTable == "PEOPLE")
                {
                    var form = new FormEditRecord(currentTable, rowView.Row, username);
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        LoadTableData("PEOPLE");
                        MessageBox.Show("Запись обновлена", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else if (currentTable == "COUNTRIES" || currentTable == "GENRES" || currentTable == "ROLES" || currentTable == "ADMINS")
                {
                    // Запрещаем редактирование, только удаление и добавление
                    MessageBox.Show("Редактирование этой таблицы запрещено из-за связей с другими данными.",
                        "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void tsbDelete_Click(object sender, EventArgs e)
        {
            if (currentDgv == null || currentDgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись для удаления", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                DataRowView rowView = currentDgv.SelectedRows[0].DataBoundItem as DataRowView;
                if (rowView == null) return;

                string pkColumn = GetPrimaryKeyColumn(currentTable);
                if (string.IsNullOrEmpty(pkColumn))
                {
                    MessageBox.Show("Не удалось определить первичный ключ", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                object pkValue = rowView.Row[pkColumn];
                string displayValue = GetDisplayValue(rowView.Row);

                DialogResult result = MessageBox.Show(
                    $"Удалить запись:\n{displayValue}?",
                    "Подтверждение удаления",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string valueStr = (pkValue is string) ? $"'{pkValue}'" : pkValue.ToString();
                    string deleteQuery = $"DELETE FROM {currentTable} WHERE {pkColumn} = {valueStr}";

                    int affected = DatabaseHelper.ExecuteNonQuery(deleteQuery);
                    if (affected > 0)
                    {
                        MessageBox.Show("Запись удалена", "Успех",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadTableData(currentTable);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tsbRefresh_Click(object sender, EventArgs e)
        {
            if (currentTable != null)
            {
                LoadTableData(currentTable);
                MessageBox.Show("Данные обновлены", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void LoadTableData(string tableName)
        {
            try
            {
                string query = $"SELECT * FROM {tableName}";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);

                switch (tableName)
                {
                    case "FILMS": dgvFilms.DataSource = dt; break;
                    case "PEOPLE": dgvPeople.DataSource = dt; break;
                    case "COUNTRIES": dgvCountries.DataSource = dt; break;
                    case "GENRES": dgvGenres.DataSource = dt; break;
                    case "ROLES": dgvRoles.DataSource = dt; break;
                    case "ADMINS": dgvAdmins.DataSource = dt; break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки таблицы {tableName}: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tsbBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormMain().Show();
        }
        private string GetPrimaryKeyColumn(string tableName)
        {
            switch (tableName.ToUpper())
            {
                case "FILMS": return "FILM_ID";
                case "PEOPLE": return "PEOPLE_ID";
                case "COUNTRIES": return "COUNTRY_CODE";
                case "GENRES": return "GENRE_NAME";
                case "ROLES": return "ROLE_NAME";
                case "ADMINS": return "LOGIN";
                default: return "";
            }
        }
        private string GetDisplayValue(DataRow row)
        {
            if (row.Table.Columns.Contains("TITLE"))
                return row["TITLE"].ToString();
            else if (row.Table.Columns.Contains("NAME"))
                return row["NAME"].ToString();
            else if (row.Table.Columns.Contains("FIRST_NAME"))
                return $"{row["FIRST_NAME"]} {row["LAST_NAME"]}";
            else if (row.Table.Columns.Contains("LOGIN"))
                return row["LOGIN"].ToString();
            else
                return row[0].ToString();
        }
        private void ShowTable(string tableName, DataGridView dgv)
        {
            dgvFilms.Visible = false;
            dgvPeople.Visible = false;
            dgvCountries.Visible = false;
            dgvGenres.Visible = false;
            dgvRoles.Visible = false;
            dgvAdmins.Visible = false;

            dgv.Visible = true;
            currentDgv = dgv;
            currentTable = tableName;
            LoadTableData(tableName);

        }
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab != null)
            {
                string tableName = tabControl1.SelectedTab.Text;
                switch (tableName)
                {
                    case "FILMS": ShowTable("FILMS", dgvFilms); break;
                    case "PEOPLE": ShowTable("PEOPLE", dgvPeople); break;
                    case "COUNTRIES": ShowTable("COUNTRIES", dgvCountries); break;
                    case "GENRES": ShowTable("GENRES", dgvGenres); break;
                    case "ROLES": ShowTable("ROLES", dgvRoles); break;
                    case "ADMINS": ShowTable("ADMINS", dgvAdmins); break;
                }

                // 🔑 ОТКЛЮЧАЕМ КНОПКУ РЕДАКТИРОВАНИЯ для таблиц с FK-ключами
                bool canEdit = (currentTable == "FILMS" || currentTable == "PEOPLE" || currentTable == "ADMINS");
                tsbEdit.Enabled = canEdit;
            

        }
        }

        private void dgvFilms_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
