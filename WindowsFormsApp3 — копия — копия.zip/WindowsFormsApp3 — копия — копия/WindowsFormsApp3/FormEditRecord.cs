﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp3
{
    
    public partial class FormEditRecord : Form
    {
        private string tableName;
        private DataRow row;
        private string username;
        private bool isNewRecord;
        private Dictionary<string, Control> fieldControls;
        private Panel mainPanel;
        private object originalPrimaryKeyValue; // ← добавь это в начало класса
        public FormEditRecord(string tableName, DataRow row, string username)
        {
            InitializeComponent();
            this.tableName = tableName.ToUpper();
            this.row = row;
            this.username = username;
            this.isNewRecord = (row == null);
            this.fieldControls = new Dictionary<string, Control>();
            CreateDynamicForm();
            if (!isNewRecord)
            {
                string pk = GetPrimaryKeyColumn();
                if (!string.IsNullOrEmpty(pk))
                {
                    originalPrimaryKeyValue = row[pk];
                }
            }

        }
    
        private void CreateDynamicForm()
        {
            mainPanel = new Panel();
            mainPanel.Dock = DockStyle.Fill;
            mainPanel.AutoScroll = true;
            mainPanel.Padding = new Padding(10);
            this.Controls.Add(mainPanel);

            if (btnBack != null) btnBack.Parent = mainPanel;
            if (bntSave != null) bntSave.Parent = mainPanel;
            if (button1 != null) button1.Parent = mainPanel;

            CreateDynamicFields();
            PositionButtons();

        }

        private void CreateDynamicFields()
        {
            int yPos = 20;
            try
            {
                string query = $"SELECT * FROM {tableName} WHERE 1=0";
                DataTable schema = DatabaseHelper.ExecuteQuery(query);

                foreach (DataColumn column in schema.Columns)
                {
                    if (ShouldSkipColumn(column.ColumnName)) continue;

                    Label label = new Label();
                    label.Text = GetRussianName(column.ColumnName) + ":";
                    label.Location = new Point(20, yPos);
                    label.Size = new Size(150, 20);
                    label.TextAlign = ContentAlignment.MiddleRight;

                    Control inputControl = CreateInputControl(column);
                    inputControl.Location = new Point(180, yPos);
                    inputControl.Size = new Size(250, 20);
                    inputControl.Name = column.ColumnName;

                    if (!isNewRecord && row[column.ColumnName] != DBNull.Value)
                    {
                        SetControlValue(inputControl, row[column.ColumnName]);
                    }

                    if (column.DataType == typeof(byte[]) ||
                        column.ColumnName.Contains("PHOTO") ||
                        column.ColumnName.Contains("POSTER"))
                    {
                        inputControl.Size = new Size(180, 20);
                        Button btnLoad = new Button();
                        btnLoad.Text = "Загрузить";
                        btnLoad.Location = new Point(370, yPos);
                        btnLoad.Size = new Size(80, 20);
                        btnLoad.Tag = inputControl;
                        btnLoad.Click += BtnLoadImage_Click;
                        mainPanel.Controls.Add(btnLoad);
                    }

                    mainPanel.Controls.Add(label);
                    mainPanel.Controls.Add(inputControl);
                    fieldControls[column.ColumnName] = inputControl;
                    yPos += 30;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка создания формы: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private bool ShouldSkipColumn(string columnName)
        {
            string[] skipColumns = {
        "CREATED_ADMIN", "CREATED_DATE", "CREATED_DATA",
        "REGISTRATION_DATE", "DATA_CREATED"
    };

            // Скрываем первичный ключ в форме
            if (columnName == GetPrimaryKeyColumn())
                return true;

            if (isNewRecord && columnName.EndsWith("_ID") &&
                columnName != "FILM_ID" && columnName != "PEOPLE_ID")
                return true;

            return skipColumns.Contains(columnName);
        }

        private Control CreateInputControl(DataColumn column)
        {
            if (column.ColumnName.Contains("DESCRIPTION") || column.ColumnName == "BIOGRAPHY")
            {
                TextBox textBox = new TextBox();
                textBox.Multiline = true;
                textBox.Height = 60;
                textBox.ScrollBars = ScrollBars.Vertical;
                return textBox;
            }
            else if (column.DataType == typeof(DateTime) ||
                     column.ColumnName.Contains("DATE") ||
                     column.ColumnName.Contains("YEAR"))
            {
                DateTimePicker dtp = new DateTimePicker();
                dtp.Format = DateTimePickerFormat.Short;
                return dtp;
            }
            else if (column.ColumnName == "FILM_ID")
            {
                TextBox tb = new TextBox();
                tb.ReadOnly = true;
                tb.BackColor = SystemColors.Control;
                return tb;
            }
        
            // 🔑 КЛЮЧЕВОЕ ИЗМЕНЕНИЕ: всегда TextBox, НИКАКИХ ComboBox!
            else if (column.ColumnName == "COUNTRY_CODE" ||
                     column.ColumnName == "GENRE_NAME" ||
                     column.ColumnName == "ROLE_NAME" ||
                     column.ColumnName == "USER_NAME")
            {
                return new TextBox(); // ← только текст!
            }
            else
            {
                return new TextBox();
            }

        }

        private ComboBox CreateCountryComboBox()
        {
            ComboBox cmb = new ComboBox();
            cmb.DropDownStyle = ComboBoxStyle.DropDownList;
            try
            {
                string query = "SELECT COUNTRY_CODE, COUNTRY_NAME FROM COUNTRIES ORDER BY COUNTRY_NAME";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                cmb.Items.Add("-- Выберите страну --");
                foreach (DataRow row in dt.Rows)
                {
                    cmb.Items.Add(new KeyValuePair<string, string>(
                        row["COUNTRY_CODE"].ToString(),
                        row["COUNTRY_NAME"].ToString()
                    ));
                }
                cmb.DisplayMember = "Value";
                cmb.ValueMember = "Key";
                cmb.SelectedIndex = 0;
            }
            catch { }
            return cmb;
        }

        private ComboBox CreateGenreComboBox() { return new ComboBox(); }
        private ComboBox CreateRoleComboBox() { return new ComboBox(); }
        private ComboBox CreateUserComboBox() { return new ComboBox(); }

        private string GetRussianName(string en)
        {
            var dict = new Dictionary<string, string>
            {
                { "TITLE", "Название" },
                { "FIRST_NAME", "Имя" },
                { "LAST_NAME", "Фамилия" },
                { "PATRONYMIC", "Отчество" },
                { "BIRTH_YEAR", "Дата рождения" },
                { "RELESE_YEAR", "Год выпуска" },
                { "DURATION", "Длительность" },
                { "RATING", "Рейтинг" },
                { "PRODUCT_TYPE", "Тип продукции" },
                { "DESCRIPTION", "Описание" },
                { "BIOGRAPHY", "Биография" },
                { "EMAIL", "Email" },
                { "PASWORD", "Пароль" },  // ← в базе PASWORD!
                { "LOGIN", "Логин" },
                { "USER_NAME", "Имя пользователя" },
                { "COUNTRY_CODE", "Страна" },
                { "COUNTRY_NAME", "Название страны" },
                { "GENRE_NAME", "Жанр" },
                { "ROLE_NAME", "Роль" },
                { "PHOTO", "Фото" },
                { "POSTER", "Постер" }
            };
            return dict.ContainsKey(en) ? dict[en] : en;

        }

        private void SetControlValue(Control control, object value)
        {
            if (control is TextBox textBox)
            {
                textBox.Text = value.ToString();
            }
            else if (control is DateTimePicker dtp)
            {
                if (value is DateTime dt) dtp.Value = dt;
                else if (value is int year) dtp.Value = new DateTime(year, 1, 1);
                else dtp.Value = DateTime.Now;
            }

        }
       

        private object GetControlValue(Control control)
        {
            if (control is TextBox textBox)
            {
                return textBox.Text.Trim();
            }
            else if (control is DateTimePicker dtp)
            {
                return dtp.Value;
            }
            else if (control is PictureBox pb && pb.Image != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    pb.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    return ms.ToArray();
                }
            }
            return null;

        }

        private void PositionButtons()
        {
            int maxY = 20;
            foreach (Control c in mainPanel.Controls)
            {
                if (c.Location.Y + c.Height > maxY)
                    maxY = c.Location.Y + c.Height;
            }
            if (btnBack != null) btnBack.Location = new Point(20, maxY + 20);
            if (bntSave != null) bntSave.Location = new Point(120, maxY + 20);
            if (button1 != null) button1.Location = new Point(220, maxY + 20);
            mainPanel.Height = maxY + 80;

        }

        private void BtnLoadImage_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Control target = (Control)btn.Tag;
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Images|*.jpg;*.jpeg;*.png;*.bmp";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    PictureBox pb = new PictureBox();
                    pb.SizeMode = PictureBoxSizeMode.Zoom;
                    pb.Size = new Size(180, 150);
                    pb.Location = target.Location;
                    pb.Name = target.Name;
                    pb.Image = Image.FromFile(dlg.FileName);
                    mainPanel.Controls.Remove(target);
                    mainPanel.Controls.Add(pb);
                    fieldControls[target.Name] = pb;
                    btn.Tag = pb;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        // === КНОПКИ СО СТАРЫМИ ИМЕНАМИ ===

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (Control ctrl in fieldControls.Values)
            {
                if (ctrl is TextBox tb) tb.Clear();
                else if (ctrl is DateTimePicker dtp) dtp.Value = DateTime.Now;
                else if (ctrl is PictureBox pb) pb.Image = null;
            }

        }
        
        private void bntSave_Click(object sender, EventArgs e)
        {
            try
            {
                // Собираем поля БЕЗ первичного ключа и системных
                string pkColumn = GetPrimaryKeyColumn();
                List<string> columns = new List<string>();
                List<string> values = new List<string>();

                foreach (var kvp in fieldControls)
                {
                    string columnName = kvp.Key;
                    Control control = kvp.Value;

                    if (columnName == pkColumn) continue; // ← КЛЮЧЕВОЕ ИЗМЕНЕНИЕ!
                    if (columnName.Contains("CREATED_") || columnName.Contains("DATE")) continue;

                    if (control is TextBox textBox && !string.IsNullOrEmpty(textBox.Text))
                    {
                        columns.Add(columnName);
                        values.Add($"'{textBox.Text.Replace("'", "''")}'");
                    }
                    else if (control is DateTimePicker dtp)
                    {
                        columns.Add(columnName);
                        values.Add($"'{dtp.Value:yyyy-MM-dd}'");
                    }
                    else if (control is PictureBox pb && pb.Image != null)
                    {
                        columns.Add(columnName);
                        values.Add("NULL"); // BLOB пока не поддерживается в этом режиме
                    }
                }

                // Добавляем CREATED_ADMIN
                columns.Add("CREATED_ADMIN");
                values.Add($"'{username}'");

                string sql;
                if (isNewRecord)
                {
                    // INSERT — PK НЕ передаём → триггер сам сгенерирует
                    sql = $"INSERT INTO {tableName} ({string.Join(", ", columns)}) VALUES ({string.Join(", ", values)})";
                }
                else
                {
                    // UPDATE — SET только то, что не PK
                    string setClause = "";
                    for (int i = 0; i < columns.Count; i++)
                    {
                        if (columns[i] != pkColumn) // ← хотя PK и так исключён
                            setClause += $"{columns[i]} = {values[i]}, ";
                    }
                    setClause = setClause.TrimEnd(',', ' ');

                    // WHERE по исходному значению PK
                    object pkValue = row[pkColumn];
                    string pkValueStr = (pkValue is string) ? $"'{pkValue}'" : pkValue.ToString();
                    sql = $"UPDATE {tableName} SET {setClause} WHERE {pkColumn} = {pkValueStr}";
                }

                int result = DatabaseHelper.ExecuteNonQuery(sql);
                if (result > 0)
                {
                    MessageBox.Show(isNewRecord ? "Добавлено!" : "Обновлено!", "Успех");
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Close();
        }

        private string GetPrimaryKey()
        {
            switch (tableName)
            {
                case "FILMS": return "FILM_ID";
                case "PEOPLE": return "PEOPLE_ID";
                case "COUNTRIES": return "COUNTRY_CODE";
                case "GENRES": return "GENRE_NAME";
                case "ROLES": return "ROLE_NAME";
                case "ADMINS": return "LOGIN"; // ← для ADMINS — LOGIN
                default: return "";
            }
        }
        private string GetPrimaryKeyColumn()
        {
            switch (tableName.ToUpper())
            {
                case "FILMS": return "FILM_ID";
                case "PEOPLE": return "PEOPLE_ID";
                case "COUNTRIES": return "COUNTRY_CODE";
                case "GENRES": return "GENRE_NAME";
                case "ROLES": return "ROLE_NAME";
                case "ADMINS": return "LOGIN";
                default: return "";
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

    }
}
