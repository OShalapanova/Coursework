﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;


namespace WindowsFormsApp3
{
    public partial class FormUser : Form

    {
        private string username;
        public FormUser(string username)
        {
            this.username = username;
            InitializeComponent();
            SetupForm();
            LoadData();

        }
        private void SetupForm()
        {
            this.Text = $"Кинотека - Пользователь: {username}";

            // Настройка таблиц
            dvgFilms.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dvgFilms.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dvgFilms.ReadOnly = true;

            dvgCollections.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dvgCollections.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dvgCollections.ReadOnly = true;

            // Настройка фильтров (БЕЗ КНОПОК!)
            cmbGenreFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCountryFilter.DropDownStyle = ComboBoxStyle.DropDownList;
        }
        private void LoadData()
        {
            LoadFilms();        // ← метод БЕЗ кнопки
            LoadCollections();  // ← метод БЕЗ кнопки
            LoadFilters();      // ← метод БЕЗ кнопки
        }
        private void LoadFilms()
        {
            try
            {
                string query = @"
            SELECT 
                f.FILM_ID as ""ID"",
                f.TITLE as ""Название"",
                f.RELESE_YEAR as ""Год"",
                f.PRODUCT_TYPE as ""Тип"",
                f.DURATION as ""Длительность"",
                f.RATING as ""Рейтинг""
            FROM FILMS f
            ORDER BY f.TITLE";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dvgFilms.DataSource = dt;

                // Проверяем, что колонка ID существует
                if (!dvgFilms.Columns.Contains("ID"))
                {
                    MessageBox.Show("Ошибка: в DataGridView нет колонки 'ID'!", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки фильмов: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadCollections()
        {
            try
            {
                string query = $@"
                    SELECT 
                        COLLECTIONS_ID as ""ID"", 
                        TITLE as ""Название""
                    FROM COLLECTIONS 
                    WHERE USER_NAME = '{username}'";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dvgCollections.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки коллекций: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadFilters()
        {
            try
            {
                // Жанры
                cmbGenreFilter.Items.Clear();
                cmbGenreFilter.Items.Add("Все жанры");
                string genreQuery = "SELECT GENRE_NAME FROM GENRES ORDER BY GENRE_NAME";
                DataTable genres = DatabaseHelper.ExecuteQuery(genreQuery);
                foreach (DataRow row in genres.Rows)
                {
                    cmbGenreFilter.Items.Add(row["GENRE_NAME"].ToString());
                }
                cmbGenreFilter.SelectedIndex = 0;

                // Страны
                cmbCountryFilter.Items.Clear();
                cmbCountryFilter.Items.Add("Все страны");
                string countryQuery = "SELECT COUNTRY_NAME FROM COUNTRIES ORDER BY COUNTRY_NAME";
                DataTable countries = DatabaseHelper.ExecuteQuery(countryQuery);
                foreach (DataRow row in countries.Rows)
                {
                    cmbCountryFilter.Items.Add(row["COUNTRY_NAME"].ToString());
                }
                cmbCountryFilter.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки фильтров: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblCountry_Click(object sender, EventArgs e)
        {

        }

        private void bntBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormMain().Show();
        }

        private void bntNewCollection_Click(object sender, EventArgs e)
        {
            string collectionName = Microsoft.VisualBasic.Interaction.InputBox(
        "Введите название коллекции:",
        "Новая коллекция",
        "Моя коллекция");

            if (!string.IsNullOrEmpty(collectionName))
            {
                try
                {
                    // username - это USER_NAME из таблицы USERS
                    string query = $@"
                INSERT INTO COLLECTIONS (TITLE, USER_NAME) 
                VALUES ('{collectionName}', '{username}')";

                    DatabaseHelper.ExecuteNonQuery(query);
                    MessageBox.Show("Коллекция создана!", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LoadCollections();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка создания коллекции: {ex.Message}",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void bntEditCollection_Click(object sender, EventArgs e)
        {
            if (dvgCollections.SelectedRows.Count > 0)
            {
                int collectionId = Convert.ToInt32(dvgCollections.SelectedRows[0].Cells["ID"].Value);
                string currentName = dvgCollections.SelectedRows[0].Cells["Название"].Value.ToString();

                string newName = Microsoft.VisualBasic.Interaction.InputBox(
                    "Введите новое название:",
                    "Редактирование коллекции",
                    currentName);

                if (!string.IsNullOrEmpty(newName))
                {
                    try
                    {
                        string query = $@"
                            UPDATE COLLECTIONS 
                            SET TITLE = '{newName}'
                            WHERE COLLECTIONS_ID = {collectionId}";

                        DatabaseHelper.ExecuteNonQuery(query);
                        MessageBox.Show("Коллекция обновлена!", "Успех",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);

                        LoadCollections(); // ← Автоматическое обновление
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите коллекцию для редактирования", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void bntDeleteCollection_Click(object sender, EventArgs e)
        {
            if (dvgCollections.SelectedRows.Count > 0)
            {
                int collectionId = Convert.ToInt32(dvgCollections.SelectedRows[0].Cells["ID"].Value);
                string collectionName = dvgCollections.SelectedRows[0].Cells["Название"].Value.ToString();

                DialogResult result = MessageBox.Show(
                    $"Удалить коллекцию '{collectionName}'?",
                    "Подтверждение удаления",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        string deleteQuery = $"DELETE FROM COLLECTIONS WHERE COLLECTIONS_ID = {collectionId}";
                        int affected = DatabaseHelper.ExecuteNonQuery(deleteQuery);

                        if (affected > 0)
                        {
                            MessageBox.Show("Коллекция удалена", "Успех",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadCollections(); // ← Автоматическое обновление
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите коллекцию для удаления", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void cmbGenreFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void cmbCountryFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }
        private void ApplyFilters()
        {
            try
            {
                string search = txtSearch.Text.Trim();
                string genre = cmbGenreFilter.SelectedIndex > 0 ? cmbGenreFilter.Text : "";
                string country = cmbCountryFilter.SelectedIndex > 0 ? cmbCountryFilter.Text : "";

                string query = @"
                    SELECT 
                        f.FILM_ID as ""ID"",
                        f.TITLE as ""Название"",
                        f.RELESE_YEAR as ""Год"",
                        f.PRODUCT_TYPE as ""Тип"",
                        f.DURATION as ""Длительность"",
                        f.RATING as ""Рейтинг""
                    FROM FILMS f
                    WHERE 1=1";

                if (!string.IsNullOrEmpty(search))
                {
                    query += $" AND (UPPER(f.TITLE) LIKE UPPER('%{search}%'))";
                }

                if (!string.IsNullOrEmpty(genre))
                {
                    query += $" AND EXISTS (SELECT 1 FROM FILM_GENRE fg WHERE fg.FILM_ID = f.FILM_ID AND fg.GENRE_NAME = '{genre}')";
                }

                if (!string.IsNullOrEmpty(country))
                {
                    query += $" AND EXISTS (SELECT 1 FROM COUNTRIES c WHERE c.COUNTRY_NAME = '{country}' AND c.COUNTRY_CODE = f.COUNTRY_CODE)";
                }

                query += " ORDER BY f.TITLE";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dvgFilms.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка фильтрации: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dvgFilms_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                try
                {
                    // Получаем ID фильма
                    object filmIdObj = dvgFilms.Rows[e.RowIndex].Cells["ID"].Value;

                    if (filmIdObj != null)
                    {
                        int filmId = Convert.ToInt32(filmIdObj);
                        FormFilmDetails detailsForm = new FormFilmDetails(filmId, username);
                        detailsForm.ShowDialog();
                    }
                    else
                    {
                        // Альтернативный способ - получить из источника данных
                        DataTable filmsTable = (DataTable)dvgFilms.DataSource;
                        if (filmsTable != null && e.RowIndex < filmsTable.Rows.Count)
                        {
                            DataRow row = filmsTable.Rows[e.RowIndex];
                            if (row["ID"] != DBNull.Value)
                            {
                                int filmId = Convert.ToInt32(row["ID"]);
                                FormFilmDetails detailsForm = new FormFilmDetails(filmId, username);
                                detailsForm.ShowDialog();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка открытия деталей фильма: {ex.Message}", "Ошибка");
                }
            }
        }

        private void dvgCollections_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            try
            {
                // Получаем ID коллекции
                if (dvgCollections.Rows[e.RowIndex].Cells["ID"].Value != null)
                {
                    int collectionId = Convert.ToInt32(dvgCollections.Rows[e.RowIndex].Cells["ID"].Value);
                    ViewCollection(collectionId);
                }
                else
                {
                    MessageBox.Show("Не удалось получить ID коллекции", "Ошибка");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка открытия коллекции: {ex.Message}", "Ошибка");
            }
        }
        private void ViewCollection(int collectionId)
        {
            try
            {
                // Получаем название коллекции
                string collectionQuery = $"SELECT TITLE FROM COLLECTIONS WHERE COLLECTIONS_ID = {collectionId}";
                DataTable collectionData = DatabaseHelper.ExecuteQuery(collectionQuery);

                if (collectionData.Rows.Count == 0)
                {
                    MessageBox.Show("Коллекция не найдена", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string collectionName = collectionData.Rows[0]["TITLE"].ToString();

                // Создаем форму для просмотра коллекции
                Form viewForm = new Form();
                viewForm.Text = $"Коллекция: {collectionName}";
                viewForm.Size = new Size(800, 500);
                viewForm.StartPosition = FormStartPosition.CenterParent;

                // DataGridView для фильмов
                DataGridView dgv = new DataGridView();
                dgv.Name = "dgvCollectionFilms";
                dgv.Dock = DockStyle.Top;
                dgv.Height = 400;
                dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgv.ReadOnly = true;
                dgv.AllowUserToAddRows = false;
                dgv.AllowUserToDeleteRows = false;

                // Загружаем фильмы коллекции
                string filmsQuery = $@"
            SELECT 
                f.FILM_ID as 'ID',
                f.TITLE as 'Название фильма',
                f.RELESE_YEAR as 'Год выпуска',
                f.PRODUCT_TYPE as 'Тип',
                f.DURATION as 'Длительность (мин)',
                f.RATING as 'Рейтинг'
            FROM FILMS f
            INNER JOIN FILM_COLLECTION fc ON f.FILM_ID = fc.FILM
            WHERE fc.COLLECTION = {collectionId}
            ORDER BY f.TITLE";

                DataTable filmsData = DatabaseHelper.ExecuteQuery(filmsQuery);
                dgv.DataSource = filmsData;

                // Скрываем колонку ID
                if (dgv.Columns.Contains("ID"))
                {
                    dgv.Columns["ID"].Visible = false;
                }

                // Панель для кнопок
                Panel buttonPanel = new Panel();
                buttonPanel.Dock = DockStyle.Bottom;
                buttonPanel.Height = 50;
                buttonPanel.Padding = new Padding(10);

                // Кнопка "Назад"
                Button btnBack = new Button();
                btnBack.Text = "Назад";
                btnBack.Size = new Size(100, 30);
                btnBack.Location = new Point(10, 10);
                btnBack.Click += (s, ev) => viewForm.Close();

                // Кнопка "Удалить фильм"
                Button btnRemove = new Button();
                btnRemove.Text = "Удалить фильм";
                btnRemove.Size = new Size(120, 30);
                btnRemove.Location = new Point(120, 10);
                btnRemove.Click += (s, ev) =>
                {
                    if (dgv.SelectedRows.Count > 0)
                    {
                        int filmId = Convert.ToInt32(dgv.SelectedRows[0].Cells["ID"].Value);
                        string filmName = dgv.SelectedRows[0].Cells["Название фильма"].Value.ToString();

                        DialogResult result = MessageBox.Show(
                            $"Удалить фильм '{filmName}' из коллекции '{collectionName}'?",
                            "Подтверждение удаления",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question);

                        if (result == DialogResult.Yes)
                        {
                            try
                            {
                                string deleteQuery = $"DELETE FROM FILM_COLLECTION WHERE FILM = {filmId} AND COLLECTION = {collectionId}";
                                DatabaseHelper.ExecuteNonQuery(deleteQuery);

                                // Обновляем список
                                DataTable updatedData = DatabaseHelper.ExecuteQuery(filmsQuery);
                                dgv.DataSource = updatedData;

                                MessageBox.Show($"Фильм '{filmName}' удален из коллекции", "Успех",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Выберите фильм для удаления", "Информация",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                };

                // Кнопка "Добавить фильм"
                Button btnAdd = new Button();
                btnAdd.Text = "Добавить фильм";
                btnAdd.Size = new Size(120, 30);
                btnAdd.Location = new Point(250, 10);
                btnAdd.Click += (s, ev) =>
                {
                    // Открываем форму выбора фильмов
                    AddFilmToCollection(collectionId, viewForm, filmsQuery, dgv);
                };

                // Метка с количеством фильмов
                Label lblCount = new Label();
                lblCount.Text = $"Фильмов в коллекции: {filmsData.Rows.Count}";
                lblCount.AutoSize = true;
                lblCount.Location = new Point(380, 15);
                lblCount.Font = new Font(lblCount.Font, FontStyle.Bold);

                // Обработчик двойного клика по фильму
                dgv.CellDoubleClick += (s, ev) =>
                {
                    if (ev.RowIndex >= 0 && dgv.Rows[ev.RowIndex].Cells["ID"].Value != null)
                    {
                        int filmId = Convert.ToInt32(dgv.Rows[ev.RowIndex].Cells["ID"].Value);
                        viewForm.Hide();
                        FormFilmDetails detailsForm = new FormFilmDetails(filmId, username);
                        detailsForm.ShowDialog();
                        viewForm.Show();
                    }
                };

                // Добавляем элементы
                buttonPanel.Controls.Add(btnBack);
                buttonPanel.Controls.Add(btnRemove);
                buttonPanel.Controls.Add(btnAdd);
                buttonPanel.Controls.Add(lblCount);

                viewForm.Controls.Add(dgv);
                viewForm.Controls.Add(buttonPanel);

                viewForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки коллекции: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddFilmToCollection(int collectionId, Form parentForm, string refreshQuery, DataGridView dgv)
        {
            try
            {
                // Форма для выбора фильмов
                Form selectForm = new Form();
                selectForm.Text = "Добавить фильм в коллекцию";
                selectForm.Size = new Size(600, 400);
                selectForm.StartPosition = FormStartPosition.CenterParent;

                // DataGridView со всеми фильмами
                DataGridView dgvAllFilms = new DataGridView();
                dgvAllFilms.Name = "dgvAllFilms";
                dgvAllFilms.Dock = DockStyle.Top;
                dgvAllFilms.Height = 300;
                dgvAllFilms.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvAllFilms.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgvAllFilms.ReadOnly = true;

                // Загружаем все фильмы, которые еще не в коллекции
                string query = $@"
            SELECT 
                f.FILM_ID as 'ID',
                f.TITLE as 'Название',
                f.RELESE_YEAR as 'Год',
                f.RATING as 'Рейтинг'
            FROM FILMS f
            WHERE NOT EXISTS (
                SELECT 1 FROM FILM_COLLECTION fc 
                WHERE fc.FILM = f.FILM_ID AND fc.COLLECTION = {collectionId}
            )
            ORDER BY f.TITLE";

                DataTable allFilms = DatabaseHelper.ExecuteQuery(query);
                dgvAllFilms.DataSource = allFilms;

                if (dgvAllFilms.Columns.Contains("ID"))
                {
                    dgvAllFilms.Columns["ID"].Visible = false;
                }

                // Кнопки
                Button btnAdd = new Button();
                btnAdd.Text = "Добавить выбранный";
                btnAdd.Size = new Size(150, 30);
                btnAdd.Location = new Point(10, 310);
                btnAdd.Click += (s, ev) =>
                {
                    if (dgvAllFilms.SelectedRows.Count > 0)
                    {
                        int filmId = Convert.ToInt32(dgvAllFilms.SelectedRows[0].Cells["ID"].Value);
                        string filmName = dgvAllFilms.SelectedRows[0].Cells["Название"].Value.ToString();

                        try
                        {
                            string insertQuery = $"INSERT INTO FILM_COLLECTION (FILM, COLLECTION) VALUES ({filmId}, {collectionId})";
                            DatabaseHelper.ExecuteNonQuery(insertQuery);

                            MessageBox.Show($"Фильм '{filmName}' добавлен в коллекцию", "Успех",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Обновляем список в родительской форме
                            DataTable updatedData = DatabaseHelper.ExecuteQuery(refreshQuery);
                            dgv.DataSource = updatedData;

                            // Обновляем список доступных фильмов
                            DataTable newAllFilms = DatabaseHelper.ExecuteQuery(query);
                            dgvAllFilms.DataSource = newAllFilms;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Выберите фильм для добавления", "Информация",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                };

                Button btnCancel = new Button();
                btnCancel.Text = "Отмена";
                btnCancel.Size = new Size(100, 30);
                btnCancel.Location = new Point(170, 310);
                btnCancel.Click += (s, ev) => selectForm.Close();

                selectForm.Controls.Add(dgvAllFilms);
                selectForm.Controls.Add(btnAdd);
                selectForm.Controls.Add(btnCancel);

                selectForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
