﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormFilmDetails : Form
    {
        private int filmId;
        private string username;
        public FormFilmDetails(int filmId, string username)
        {
            InitializeComponent();
            this.filmId = filmId;
            this.username = username;
            LoadFilmDetails();
        }
        private void LoadFilmDetails()
        {
            try
            {
                // 1. Загрузка основной информации о фильме
                string query = $@"
                    SELECT 
                        f.TITLE,
                        f.RELESE_YEAR,
                        f.PRODUCT_TYPE,
                        f.DURATION,
                        f.RATING,
                        f.DESCRIPTION,
                        c.COUNTRY_NAME,
                        f.POSTER
                    FROM FILMS f
                    LEFT JOIN COUNTRIES c ON f.COUNTRY_CODE = c.COUNTRY_CODE
                    WHERE f.FILM_ID = {filmId}";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);

                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];

                    // Заполнение полей
                    lblTitle.Text = row["TITLE"].ToString();
                    lblYear.Text = $"Год: {row["RELESE_YEAR"]}";
                    lblType.Text = $"Тип: {row["PRODUCT_TYPE"]}";
                    lblDuration.Text = $"Длительность: {row["DURATION"]} мин";
                    lblRating.Text = $"Рейтинг: {row["RATING"]}";
                    lblCountry.Text = $"Страна: {row["COUNTRY_NAME"]}";
                    txtDescription.Text = row["DESCRIPTION"].ToString();

                    // Загрузка постера
                    if (row["POSTER"] != DBNull.Value)
                    {
                        byte[] imageBytes = (byte[])row["POSTER"];
                        pbPoster.Image = DatabaseHelper.GetImageFromBytes(imageBytes);
                    }
                }

                // 2. Загрузка съемочной группы
                LoadFilmCrew();

                // 3. Загрузка жанров
                LoadFilmGenres();

                // 4. Загрузка коллекций пользователя
                LoadUserCollections();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadFilmCrew()
        {
            try
            {
                string query = $@"
    SELECT 
        p.FIRST_NAME || ' ' || p.LAST_NAME AS Имя,
        r.ROLE_NAME AS Роль,
        fc.ROLE_FILM AS Описание_роли
    FROM FILM_CREW fc
    JOIN PEOPLE p ON fc.PEOPLE_ID = p.PEOPLE_ID
    JOIN ROLES r ON fc.TITLE_ROLE = r.ROLE_NAME
    WHERE fc.FILM_ID = {filmId}
    ORDER BY r.ROLE_NAME";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgvCrew.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки группы: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadFilmGenres()
        {
            try
            {
                string query = $@"
                    SELECT g.GENRE_NAME
                    FROM FILM_GENRE fg
                    JOIN GENRES g ON fg.GENRE_NAME = g.GENRE_NAME
                    WHERE fg.FILM_ID = {filmId}";

                DataTable dt = DatabaseHelper.ExecuteQuery(query);

                string genres = "Жанры: ";
                foreach (DataRow row in dt.Rows)
                {
                    genres += row["GENRE_NAME"].ToString() + ", ";
                }

                if (dt.Rows.Count > 0)
                {
                    genres = genres.Substring(0, genres.Length - 2);
                }

                lblGenres.Text = genres;
            }
            catch (Exception ex)
            {
                lblGenres.Text = "Жанры: не загружены";
            }
        }

        private void LoadUserCollections()
        {
            try
            {
                string query = $@"
    SELECT 
        c.COLLECTIONS_ID AS ID,
        c.TITLE AS Коллекция,
        CASE WHEN fc.FILM IS NOT NULL THEN '✓' ELSE '' END AS В_коллекции
    FROM COLLECTIONS c
    LEFT JOIN FILM_COLLECTION fc ON c.COLLECTIONS_ID = fc.COLLECTION AND fc.FILM = {filmId}
    WHERE c.USER_NAME = '{username}'";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgvUserCollections.DataSource = dt;
                if (dgvUserCollections.Columns.Contains("ID"))
                {
                    dgvUserCollections.Columns["ID"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки коллекций: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bntBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvCrew_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Получаем имя человека
                string personName = dgvCrew.Rows[e.RowIndex].Cells["Имя"].Value.ToString();
                MessageBox.Show($"Детали для: {personName}\n\nЭта функция откроет детали человека.",
                    "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dgvUserCollections_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridView dgv = (DataGridView)sender;
                string collectionName = dgv.Rows[e.RowIndex].Cells["Коллекция"].Value.ToString();
                string inCollection = dgv.Rows[e.RowIndex].Cells["В коллекции"].Value.ToString();
                int collectionId = Convert.ToInt32(dgv.Rows[e.RowIndex].Cells["ID"].Value);

                if (inCollection == "✓")
                {
                    // Удалить из коллекции
                    DialogResult result = MessageBox.Show(
                        $"Удалить фильм из коллекции '{collectionName}'?",
                        "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        try
                        {
                            string deleteQuery = $"DELETE FROM FILM_COLLECTION WHERE FILM = {filmId} AND COLLECTION = {collectionId}";
                            DatabaseHelper.ExecuteNonQuery(deleteQuery);
                            LoadUserCollections();
                            MessageBox.Show("Фильм удален из коллекции", "Успех",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    // Добавить в коллекцию
                    try
                    {
                        string insertQuery = $"INSERT INTO FILM_COLLECTION (FILM, COLLECTION) VALUES ({filmId}, {collectionId})";
                        DatabaseHelper.ExecuteNonQuery(insertQuery);
                        LoadUserCollections();
                        MessageBox.Show("Фильм добавлен в коллекцию", "Успех",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Фильм уже в коллекции: {ex.Message}", "Ошибка",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
         }
    }
}
